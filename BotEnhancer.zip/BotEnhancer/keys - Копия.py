# /ErrrorBot/keys.py

# Токен вашего бота от @BotFather
BOT_TOKEN = "токен"

# Список числовых Telegram ID администраторов бота
# Пример: ADMIN_IDS = [123456789] или ADMIN_IDS = [123456789, 987654321]
ADMIN_IDS = [1234]