# /ErrrorBot/app/services/g4f_api.py

import asyncio
import logging
import re
import time
import random

try:
    from g4f.client import Client
    from g4f import ChatCompletion, Provider
    import g4f
    G4F_AVAILABLE = True
except ImportError:
    G4F_AVAILABLE = False
    logging.error("g4f не установлен")

from config import settings
from app.services.huggingface_datasets import hf_datasets_service
from app.services.working_advanced_datasets import working_advanced_datasets_service

class G4FAPI:
    def __init__(self):
        """Простой G4F API - только реально работающие провайдеры"""
        self.max_tokens = settings.max_tokens
        self.client = Client() if G4F_AVAILABLE else None
        
        logging.info(f"G4F API инициализирован")

    def _clean_response(self, text: str) -> str:
        """Очистка ответа"""
        if not text:
            return ""
        text = text.strip()
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
        text = re.sub(r'\[thinking\].*?\[/thinking\]', '', text, flags=re.DOTALL)
        text = re.sub(r'\n\n+', '\n\n', text)
        return text.strip()

    async def generate_text(self, prompt: str, system_prompt: str = None) -> str:
        """Генерация - только проверенные провайдеры"""
        
        if not G4F_AVAILABLE:
            return "❌ G4F недоступен"
        
        # Улучшаем системный промпт с помощью ВСЕХ датасетов (базовые + продвинутые)
        enhanced_system_prompt = system_prompt
        if system_prompt:
            # Сначала используем базовые датасеты
            if hf_datasets_service.knowledge_base:
                enhanced_system_prompt = hf_datasets_service.get_enhanced_system_prompt(system_prompt, prompt)
            
            # Добавляем РАБОЧИЕ продвинутые знания для максимального разума
            if working_advanced_datasets_service.knowledge_vault:
                advanced_context = working_advanced_datasets_service.search_advanced_context(prompt, max_results=3)
                if advanced_context:
                    enhanced_system_prompt += f"\n\n{advanced_context}"
        
        messages = []
        if enhanced_system_prompt:
            messages.append({"role": "system", "content": enhanced_system_prompt})
        messages.append({"role": "user", "content": prompt})

        # ИСПРАВЛЕННЫЕ РАБОЧИЕ СТРАТЕГИИ (фикс попытки номер 1)
        strategies = [
            # Blackbox - самый стабильный провайдер (фиксит попытку 1)
            lambda: g4f.ChatCompletion.create(model="blackboxai", messages=messages, provider=g4f.Provider.Blackbox),
            lambda: g4f.ChatCompletion.create(model="gpt-4o-mini", messages=messages, provider=g4f.Provider.Blackbox),
            
            # Автовыбор с улучшенной обработкой ошибок
            lambda: g4f.ChatCompletion.create(model="gpt-4o", messages=messages),
            lambda: g4f.ChatCompletion.create(model="gpt-4o-mini", messages=messages), 
            lambda: g4f.ChatCompletion.create(model="gpt-3.5-turbo", messages=messages),
            lambda: g4f.ChatCompletion.create(model="claude-3.5-sonnet", messages=messages),
            
            # DeepSeek - новейшие модели
            lambda: g4f.ChatCompletion.create(model="deepseek-v3", messages=messages),
            lambda: g4f.ChatCompletion.create(model="deepseek-r1", messages=messages),
            
            # Простые модели без привязки к провайдеру  
            lambda: g4f.ChatCompletion.create(model="llama-3.1-70b", messages=messages),
            lambda: g4f.ChatCompletion.create(model="mixtral-8x7b", messages=messages),
            lambda: g4f.ChatCompletion.create(model="qwen-72b", messages=messages)
        ]
        
        # Перемешиваем для распределения
        random.shuffle(strategies)
        
        print(f"Генерация для: {prompt[:30]}...")
        
        for i, strategy in enumerate(strategies, 1):
            try:
                print(f"Попытка {i}: ", end="", flush=True)
                
                response = await asyncio.wait_for(
                    asyncio.to_thread(strategy),
                    timeout=25.0
                )
                
                # Извлекаем текст из ответа
                response_text = ""
                if isinstance(response, str):
                    response_text = response
                elif hasattr(response, 'content'):
                    response_text = response.content
                elif hasattr(response, 'choices') and response.choices:
                    if hasattr(response.choices[0], 'message'):
                        response_text = response.choices[0].message.content
                    else:
                        response_text = str(response.choices[0])
                else:
                    response_text = str(response)
                
                if response_text and len(response_text.strip()) > 5:
                    cleaned = self._clean_response(response_text)
                    print(f"✅ Успех! Длина: {len(cleaned)}")
                    return cleaned
                else:
                    print("❌ Пустой ответ")
                        
            except Exception as e:
                error = str(e)[:40]
                print(f"❌ {error}")
                continue
        
        return "❌ Все провайдеры недоступны"

    async def test_speed(self):
        """Тест скорости только рабочих провайдеров"""
        print("\n⚡ Тест провайдеров:")
        
        messages = [{"role": "user", "content": "Hello"}]
        
        tests = [
            ("DeepSeek V3 (Together)", lambda: ChatCompletion.create(model="deepseek-v3", messages=messages, provider=g4f.Provider.Together)),
            ("DeepSeek V3 (Auto)", lambda: ChatCompletion.create(model="deepseek-v3", messages=messages)),
            ("Blackbox AI", lambda: ChatCompletion.create(model="blackboxai", messages=messages, provider=g4f.Provider.Blackbox)),
            ("GPT-4o (Blackbox)", lambda: ChatCompletion.create(model="gpt-4o", messages=messages, provider=g4f.Provider.Blackbox)),
            ("Llama-3.3-70b (Together)", lambda: ChatCompletion.create(model="llama-3.3-70b", messages=messages, provider=g4f.Provider.Together))
        ]
        
        for name, method in tests:
            try:
                start_time = time.time()
                response = await asyncio.wait_for(asyncio.to_thread(method), timeout=15.0)
                
                response_text = ""
                if hasattr(response, 'choices') and response.choices:
                    response_text = response.choices[0].message.content
                elif isinstance(response, str):
                    response_text = response
                elif hasattr(response, 'content'):
                    response_text = response.content
                
                if response_text and len(response_text.strip()) > 0:
                    elapsed = time.time() - start_time
                    print(f"✅ {name}: {elapsed:.1f}s")
                else:
                    print(f"❌ {name}: Пустой ответ")
                    
            except Exception as e:
                print(f"❌ {name}: {str(e)[:30]}")

# Создаем экземпляр
g4f_api_service = G4FAPI()