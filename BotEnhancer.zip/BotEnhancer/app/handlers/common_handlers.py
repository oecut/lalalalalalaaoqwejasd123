# /ErrrorBot/app/handlers/common_handlers.py

import logging
import asyncio
import html
import re
from typing import Optional, Union

from aiogram import Bot
from aiogram.types import Message, MessageEntity
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.enums import ParseMode

from app.services.database import db
from app.services.g4f_api import g4f_api_service
from app.utils import format_ai_response_to_html, split_long_message, format_final_message_html
from config import settings
from messages import Errors

def convert_entities_to_telegram_entities(entities):
    """Конвертирует сохраненные entities обратно в формат Telegram"""
    if not entities:
        return None
    
    telegram_entities = []
    for entity_dict in entities:
        try:
            # Создаем MessageEntity из словаря
            entity = MessageEntity(
                type=entity_dict['type'],
                offset=entity_dict['offset'],
                length=entity_dict['length']
            )
            
            # Добавляем дополнительные поля если есть
            if 'url' in entity_dict:
                entity.url = entity_dict['url']
            if 'user_id' in entity_dict:
                # Создаем фиктивный User объект если нужно
                from aiogram.types import User
                entity.user = User(id=entity_dict['user_id'], is_bot=False, first_name="User")
            if 'language' in entity_dict:
                entity.language = entity_dict['language']
                
            telegram_entities.append(entity)
        except Exception as e:
            logging.warning(f"Ошибка создания entity: {e}")
            continue
    
    return telegram_entities if telegram_entities else None

async def send_safe_message(bot: Bot, chat_id: int, text: str, 
                          business_connection_id: Optional[str] = None, 
                          message_id: Optional[int] = None, 
                          edit: bool = False,
                          entities: Optional[list] = None,
                          reply_to_message_id: Optional[int] = None) -> Union[bool, int]:
    """Универсальная безопасная отправка сообщений с HTML-парсингом и разделением длинных сообщений."""
    
    # Разделяем длинное сообщение на части
    message_parts = split_long_message(text)
    
    try:
        # Если есть entities, используем их для первой части
        if entities and not edit:
            try:
                telegram_entities = convert_entities_to_telegram_entities(entities)
                if telegram_entities:
                    sent_message = await bot.send_message(
                        chat_id=chat_id,
                        text=message_parts[0],
                        business_connection_id=business_connection_id,
                        reply_to_message_id=reply_to_message_id,
                        entities=telegram_entities,
                        parse_mode=None
                    )
                    
                    # Отправляем остальные части с HTML
                    for part in message_parts[1:]:
                        await asyncio.sleep(0.1)
                        await bot.send_message(
                            chat_id=chat_id,
                            text=part,
                            business_connection_id=business_connection_id,
                            parse_mode=ParseMode.HTML
                        )
                    return sent_message.message_id if sent_message and hasattr(sent_message, 'message_id') else True
            except Exception as e:
                logging.warning(f"Не удалось отправить с entities: {e}, отправляем с HTML")
        
        # Отправляем или редактируем первую часть с HTML
        if edit and message_id:
            await bot.edit_message_text(
                text=message_parts[0],
                chat_id=chat_id,
                message_id=message_id,
                business_connection_id=business_connection_id,
                parse_mode=ParseMode.HTML
            )
        else:
            sent_message = await bot.send_message(
                chat_id=chat_id,
                text=message_parts[0],
                business_connection_id=business_connection_id,
                reply_to_message_id=reply_to_message_id,
                parse_mode=ParseMode.HTML
            )
            
            # Отправляем остальные части как новые сообщения
            for part in message_parts[1:]:
                await asyncio.sleep(0.1)
                await bot.send_message(
                    chat_id=chat_id,
                    text=part,
                    business_connection_id=business_connection_id,
                    parse_mode=ParseMode.HTML
                )
            return sent_message.message_id if sent_message and hasattr(sent_message, 'message_id') else True
            
        # Отправляем остальные части как новые сообщения для edit
        for part in message_parts[1:]:
            await asyncio.sleep(0.1)
            await bot.send_message(
                chat_id=chat_id,
                text=part,
                business_connection_id=business_connection_id,
                parse_mode=ParseMode.HTML
            )
            
        return True
        
    except (TelegramBadRequest, TelegramNetworkError) as e:
        error_str = str(e).lower()
                
        if "message_id_invalid" in error_str:
            # Неверный ID сообщения - отправляем все части как новые сообщения
            logging.warning("Неверный message_id, отправляем новые сообщения")
            try:
                sent_message = None
                for i, part in enumerate(message_parts):
                    if i > 0:
                        await asyncio.sleep(0.1)
                    message_result = await bot.send_message(
                        chat_id=chat_id,
                        text=part,
                        business_connection_id=business_connection_id,
                        reply_to_message_id=reply_to_message_id if i == 0 else None,
                        parse_mode=ParseMode.HTML
                    )
                    if i == 0:
                        sent_message = message_result
                return sent_message.message_id if sent_message and hasattr(sent_message, 'message_id') else True
            except Exception as inner_e:
                logging.error(f"Не удалось отправить новые сообщения: {inner_e}")
                return False
                
        elif "can't parse entities" in error_str:
            # Ошибка парсинга HTML - отправляем без форматирования
            logging.warning(f"Ошибка парсинга HTML. Отправка обычным текстом. Ошибка: {e}")
            try:
                # Убираем HTML теги из всех частей
                plain_parts = [re.sub('<[^<]+?>', '', part) for part in message_parts]
                
                if edit and message_id:
                    await bot.edit_message_text(
                        text=plain_parts[0],
                        chat_id=chat_id,
                        message_id=message_id,
                        business_connection_id=business_connection_id,
                        parse_mode=None
                    )
                else:
                    sent_message = await bot.send_message(
                        chat_id=chat_id,
                        text=plain_parts[0],
                        business_connection_id=business_connection_id,
                        reply_to_message_id=reply_to_message_id,
                        parse_mode=None
                    )
                    # Отправляем остальные части
                    for part in plain_parts[1:]:
                        await asyncio.sleep(0.1)
                        await bot.send_message(
                            chat_id=chat_id,
                            text=part,
                            business_connection_id=business_connection_id,
                            parse_mode=None
                        )
                    return sent_message.message_id if sent_message and hasattr(sent_message, 'message_id') else True
                
                # Отправляем остальные части для edit
                for part in plain_parts[1:]:
                    await asyncio.sleep(0.1)
                    await bot.send_message(
                        chat_id=chat_id,
                        text=part,
                        business_connection_id=business_connection_id,
                        parse_mode=None
                    )
                return True
            except Exception as inner_e:
                logging.error(f"Критическая ошибка при отправке fallback-сообщений: {inner_e}")
                return False
        else:
            logging.error(f"Неожиданная ошибка Telegram: {e}")
            return False
            
    except Exception as e:
        logging.error(f"Неожиданная ошибка при отправке сообщения: {e}")
        return False

async def run_demo_animation(message: Message, bot: Bot, demo_responses: list, entities: Optional[list] = None) -> bool:
    """
    Выполняет анимированную демонстрацию, редактируя исходное сообщение.
    Поддерживает форматирование HTML в ответах и разделение длинных сообщений.
    """
    try:
        if not demo_responses:
            return False
            
        logging.info(f"Запуск анимации для пользователя {message.from_user.id} с {len(demo_responses)} этапами")
        
        # Редактируем исходное сообщение на первый ответ
        first_response = demo_responses[0]
        
        # Если есть entities, используем их для первого сообщения
        if entities:
            try:
                telegram_entities = convert_entities_to_telegram_entities(entities)
                if telegram_entities:
                    await bot.edit_message_text(
                        text=first_response,
                        chat_id=message.chat.id,
                        message_id=message.message_id,
                        business_connection_id=message.business_connection_id,
                        entities=telegram_entities,
                        parse_mode=None
                    )
                else:
                    raise ValueError("Не удалось конвертировать entities")
            except Exception as e:
                logging.warning(f"Не удалось использовать entities для первого этапа: {e}")
                formatted_response = format_ai_response_to_html(first_response)
                success = await send_safe_message(
                    bot, message.chat.id,
                    formatted_response,
                    message.business_connection_id,
                    message.message_id,
                    edit=True
                )
                if not success:
                    logging.error("Не удалось отправить первый этап анимации")
                    return False
        else:
            formatted_response = format_ai_response_to_html(first_response)
            success = await send_safe_message(
                bot, message.chat.id,
                formatted_response,
                message.business_connection_id,
                message.message_id,
                edit=True
            )
            if not success:
                logging.error("Не удалось отправить первый этап анимации")
                return False
        
        # Анимация остальных этапов с задержкой
        for i, response_text in enumerate(demo_responses[1:], 1):
            await asyncio.sleep(1.0)  # Задержка между этапами
            formatted_response = format_ai_response_to_html(response_text)
            
            success = await send_safe_message(
                bot, message.chat.id,
                formatted_response,
                message.business_connection_id,
                message.message_id,
                edit=True
            )
            
            if success:
                logging.info(f"Этап анимации {i+1}/{len(demo_responses)} выполнен")
            else:
                logging.warning(f"Ошибка этапа анимации {i+1}")
        
        return True
        
    except Exception as e:
        logging.error(f"Ошибка выполнения демо-анимации: {e}")
        return False

async def run_simple_demo(message: Message, bot: Bot, demo_response: str, entities: Optional[list] = None) -> bool:
    """
    Выполняет простую демонстрацию без анимации.
    Поддерживает форматирование HTML в ответе и разделение длинных сообщений.
    """
    try:
        logging.info(f"Запуск простого демо для пользователя {message.from_user.id}")
        
        # Если есть entities, используем их
        if entities:
            try:
                telegram_entities = convert_entities_to_telegram_entities(entities)
                if telegram_entities:
                    await bot.edit_message_text(
                        text=demo_response,
                        chat_id=message.chat.id,
                        message_id=message.message_id,
                        business_connection_id=message.business_connection_id,
                        entities=telegram_entities,
                        parse_mode=None
                    )
                    logging.info("Простое демо с entities успешно выполнено")
                    return True
                else:
                    raise ValueError("Не удалось конвертировать entities")
            except Exception as e:
                logging.warning(f"Не удалось использовать entities: {e}")
        
        # Форматируем ответ с поддержкой HTML
        formatted_response = format_ai_response_to_html(demo_response)
        
        success = await send_safe_message(
            bot, message.chat.id,
            formatted_response,
            message.business_connection_id,
            message.message_id,
            edit=True
        )
        
        if success:
            logging.info("Простое демо успешно выполнено")
            return True
        else:
            logging.error("Не удалось выполнить простое демо")
            return False
        
    except Exception as e:
        logging.error(f"Ошибка выполнения простого демо: {e}")
        return False

async def check_user_limits(message: Message) -> bool:
    """Проверяет лимиты пользователя"""
    user_id = message.from_user.id
    
    requests_today = await db.get_user_requests_count(user_id)
    if requests_today is None:
        await db.add_or_update_user(
            user_id, 
            message.from_user.username or '', 
            message.from_user.first_name or ''
        )
        requests_today = 0
        
    if requests_today >= settings.daily_request_limit:
        # Используем общую функцию отправки
        if message.bot:
            await send_safe_message(
                message.bot, 
                message.chat.id, 
                Errors.daily_limit_reached,
                getattr(message, 'business_connection_id', None),
                message.message_id,
                edit=True
            )
        return False
    return True

def validate_prompt(prompt: str) -> tuple[bool, str]:
    """Валидация пользовательского ввода"""
    if not prompt or not prompt.strip():
        return False, "❌ Пустой запрос. Напишите что-нибудь после .ai"
    
    if len(prompt) > 1000:
        return False, "❌ Запрос слишком длинный. Максимум 1000 символов."
    
    suspicious_patterns = ['system:', 'override:', 'ignore previous', 'new instructions']
    if any(pattern in prompt.lower() for pattern in suspicious_patterns):
        return False, "❌ Подозрительный запрос отклонен."
    
    return True, ""

async def process_ai_request(message: Message, bot: Bot, prompt: str, 
                           is_business: bool = False, 
                           is_group: bool = False,
                           original_user_name: Optional[str] = None,
                           context_text: Optional[str] = None) -> bool:
    """
    Универсальная обработка AI запросов для всех типов чатов.
    """
    try:
        user_id = message.from_user.id if message.from_user else 0
        chat_id = message.chat.id
        user_name = (message.from_user.first_name if message.from_user else None) or "Пользователь"
        
        # Получаем активный стиль
        if is_group:
            active_style_prompt = await db.get_active_group_style_prompt(chat_id)
        else:
            active_style_prompt = await db.get_active_style_prompt(user_id)
        
        # Используем пустую строку если стиль не найден
        if not active_style_prompt:
            active_style_prompt = ''
        
        logging.info(f"Генерация текста для {'группы' if is_group else 'пользователя'} {user_id}: {prompt[:50]}")
        response = await g4f_api_service.generate_text(
            prompt=prompt, 
            system_prompt=active_style_prompt
        )
        
        if len(response.strip()) < 10:
            response = "Получен слишком короткий ответ. Попробуйте перефразировать запрос."
        
        # Форматируем финальный ответ в зависимости от типа чата
        if is_group:
            final_text = format_quoted_message(original_user_name or user_name, 
                                             context_text or prompt, response)
        elif is_business:
            final_text = format_final_message_html(user_name, prompt, response)
        else:
            final_text = format_quoted_message(user_name, prompt, response)
        
        # Отправляем финальный ответ
        success = await send_safe_message(
            bot, chat_id, final_text,
            message.business_connection_id if is_business else None,
            message.message_id,
            edit=True
        )
        
        if success:
            await db.increment_user_requests(user_id, 'text')
            logging.info(f"✅ Успешно обработан AI запрос {'в группе' if is_group else 'от пользователя'} {user_id}")
            return True
        else:
            logging.error("Не удалось отправить финальный ответ")
            return False
            
    except Exception as e:
        logging.error(f"Ошибка в process_ai_request: {e}")
        await send_safe_message(
            bot, message.chat.id,
            "❌ Произошла ошибка при генерации ответа. Попробуйте позже.",
            message.business_connection_id if is_business else None,
            message.message_id,
            edit=True
        )
        return False

def format_quoted_message(user_name: str, original_text: str, ai_response: str) -> str:
    """Форматирует сообщение с цитатой пользователя и ответом ИИ"""
    safe_user_name = html.escape(user_name or "Пользователь")
    safe_original_text = html.escape(original_text or "")
    formatted_ai_response = format_ai_response_to_html(ai_response)
    
    return (
        f"<blockquote>{safe_user_name}: {safe_original_text}</blockquote>\n\n"
        f"💬 <b>{formatted_ai_response}</b>"
    )