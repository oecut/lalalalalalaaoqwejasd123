# ErrrorBot - AI Telegram Bot

## Overview
ErrrorBot is a comprehensive AI-powered Telegram bot built with Python and aiogram. The bot serves as an intelligent assistant that can be used in private chats, group chats, and business connections. It leverages the g4f library to access various AI models and providers, offering customizable response styles for different chat contexts. The bot includes advanced features like dataset integration for enhanced AI responses, administrative controls, user management, and a sophisticated messaging system.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Bot Interface**: Built using aiogram framework with HTML parsing for rich message formatting
- **State Management**: Finite State Machine (FSM) using aiogram's memory storage for handling multi-step user interactions
- **Inline Keyboards**: Dynamic keyboard generation for user interaction menus, settings, and administrative functions
- **Message Handling**: Separate handlers for different chat types (private, group, business) with context-aware routing

### Backend Architecture
- **Modular Handler System**: Organized into separate routers for different functionalities:
  - User handlers for general user interactions
  - Business handlers for Telegram Business API integration
  - Group handlers for group chat management
  - Admin handlers for administrative functions
  - Private handlers for direct messaging
- **Middleware Layer**: Custom throttling middleware to prevent spam and rate limiting
- **Service Layer**: Dedicated services for database operations, AI API calls, and external integrations
- **Configuration Management**: Environment-based configuration using dataclasses for type safety

### Data Storage Solutions
- **Primary Database**: SQLite with aiosqlite for asynchronous operations
- **Connection Pooling**: Persistent database connections with WAL mode for improved performance
- **Caching**: TTL-based caching using cachetools for throttling and performance optimization
- **Data Models**: Structured storage for user preferences, chat styles, conversation history, and administrative settings

### Authentication and Authorization
- **Admin System**: Role-based access control using configurable admin user IDs
- **User Management**: Per-user settings and preferences with database persistence
- **Group Permissions**: Context-aware permissions for group chat administration
- **Rate Limiting**: Request throttling to prevent abuse and ensure fair usage

### AI Integration Architecture
- **G4F Client**: Primary AI service using g4f library with multiple provider fallback strategies
- **Dataset Enhancement**: HuggingFace datasets integration for knowledge base expansion
- **Response Processing**: Advanced text cleaning and markdown-to-HTML conversion
- **Style Customization**: User-configurable AI response styles for different contexts (personal vs group)
- **Message Formatting**: Intelligent message splitting for Telegram's character limits

## External Dependencies

### Core Framework Dependencies
- **aiogram**: Telegram Bot API framework for Python with async support
- **aiosqlite**: Asynchronous SQLite database interface
- **cachetools**: Caching utilities for performance optimization

### AI and ML Dependencies
- **g4f**: Free GPT API client for accessing various AI providers
- **datasets**: HuggingFace datasets library for knowledge enhancement
- **huggingface_hub**: HuggingFace model hub integration

### Third-Party Services
- **Telegram Bot API**: Primary platform for bot deployment and user interaction
- **Telegram Business API**: Enhanced business messaging capabilities
- **G4F Providers**: Multiple AI model providers accessed through g4f client
- **HuggingFace Hub**: Dataset repository for AI knowledge enhancement

### Development and Deployment
- **Environment Variables**: Secure configuration management for tokens and sensitive data
- **Logging System**: Comprehensive logging for monitoring and debugging
- **Error Handling**: Robust error handling with user-friendly error messages

## Recent Updates (December 2024)

### Major Bot Intelligence Enhancements ✅
- **🧠 HuggingFace Integration**: Successfully integrated finepdfs (15 documents) and gdpval (220 records) datasets for enhanced AI responses
- **🚀 Advanced Knowledge System**: Created working advanced datasets service with 32 specialized facts across 4 categories (science, technology, economics, history)
- **📊 Total Knowledge Base**: 267 documents (235 HuggingFace + 32 advanced facts) now powering AI responses

### System Stability Improvements ✅  
- **⚡ G4F Provider Optimization**: Fixed provider stability issues, prioritized reliable Blackbox provider for consistent responses
- **🛠️ Code Architecture Refactoring**: Created common_handlers.py, optimized logging, improved security with environment variables
- **💅 Enhanced User Interface**: Updated welcome messages and bot interaction flow
- **🔄 Workflow Configuration**: Stable bot startup with proper error handling and parallel dataset loading

### Current Status
- ✅ Bot successfully launches and responds to queries
- ✅ All datasets load properly during startup
- ✅ Provider errors resolved - first attempt stability achieved  
- ✅ Knowledge enhancement system operational
- ✅ Ready for production use