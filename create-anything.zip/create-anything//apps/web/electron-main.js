const { app, BrowserWindow, Menu, shell, ipcMain } = require('electron');
const path = require('path');
const isDev = process.env.NODE_ENV === 'development';

let mainWindow;

function createWindow() {
  // Создаем главное окно приложения
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, 'electron-preload.js')
    },
    icon: path.join(__dirname, 'assets', 'icon.png'),
    titleBarStyle: 'default',
    backgroundColor: '#000000',
    show: false,
    autoHideMenuBar: false
  });

  // Загружаем приложение
  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    // Открываем DevTools в разработке
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  // Показываем окно когда готово
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    
    // Фокусируемся на окне
    if (isDev) {
      mainWindow.focus();
    }
  });

  // Обработка закрытия окна
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Открываем внешние ссылки в браузере
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // Предотвращаем навигацию к внешним URL
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (url !== mainWindow.webContents.getURL()) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });
}

// Создаем меню приложения
function createMenu() {
  const template = [
    {
      label: 'GhostNet Pro',
      submenu: [
        {
          label: 'О программе',
          click: () => {
            const aboutWindow = new BrowserWindow({
              width: 400,
              height: 300,
              resizable: false,
              parent: mainWindow,
              modal: true,
              show: false,
              webPreferences: {
                nodeIntegration: false,
                contextIsolation: true
              }
            });

            aboutWindow.loadURL(`data:text/html;charset=utf-8,
              <html>
                <head>
                  <style>
                    body {
                      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                      background: linear-gradient(135deg, #000000, #1a1a1a);
                      color: white;
                      text-align: center;
                      padding: 40px 20px;
                      margin: 0;
                    }
                    h1 { color: #00D4FF; margin-bottom: 10px; }
                    .version { color: #888; margin-bottom: 20px; }
                    .description { line-height: 1.6; }
                  </style>
                </head>
                <body>
                  <h1>🛡️ GhostNet Pro</h1>
                  <div class="version">Версия 1.0.0</div>
                  <div class="description">
                    Максимальная анонимность и защита в интернете.<br>
                    Профессиональные инструменты для приватности.
                  </div>
                </body>
              </html>
            `);

            aboutWindow.once('ready-to-show', () => {
              aboutWindow.show();
            });
          }
        },
        { type: 'separator' },
        {
          label: 'Настройки',
          accelerator: 'CmdOrCtrl+,',
          click: () => {
            mainWindow.webContents.send('open-settings');
          }
        },
        { type: 'separator' },
        {
          label: 'Выход',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'Защита',
      submenu: [
        {
          label: 'Быстрое подключение VPN',
          accelerator: 'CmdOrCtrl+V',
          click: () => {
            mainWindow.webContents.send('quick-vpn');
          }
        },
        {
          label: 'Скрыть IP адрес',
          accelerator: 'CmdOrCtrl+H',
          click: () => {
            mainWindow.webContents.send('toggle-ip-hiding');
          }
        },
        {
          label: 'Блокировка трекеров',
          accelerator: 'CmdOrCtrl+T',
          click: () => {
            mainWindow.webContents.send('toggle-tracker-blocking');
          }
        },
        { type: 'separator' },
        {
          label: 'Сканирование безопасности',
          accelerator: 'CmdOrCtrl+S',
          click: () => {
            mainWindow.webContents.send('start-security-scan');
          }
        }
      ]
    },
    {
      label: 'Вид',
      submenu: [
        {
          label: 'Обновить',
          accelerator: 'CmdOrCtrl+R',
          click: () => {
            mainWindow.reload();
          }
        },
        {
          label: 'Полный экран',
          accelerator: process.platform === 'darwin' ? 'Ctrl+Cmd+F' : 'F11',
          click: () => {
            mainWindow.setFullScreen(!mainWindow.isFullScreen());
          }
        },
        { type: 'separator' },
        {
          label: 'Масштаб',
          submenu: [
            {
              label: 'Увеличить',
              accelerator: 'CmdOrCtrl+Plus',
              click: () => {
                const currentZoom = mainWindow.webContents.getZoomLevel();
                mainWindow.webContents.setZoomLevel(currentZoom + 0.5);
              }
            },
            {
              label: 'Уменьшить',
              accelerator: 'CmdOrCtrl+-',
              click: () => {
                const currentZoom = mainWindow.webContents.getZoomLevel();
                mainWindow.webContents.setZoomLevel(currentZoom - 0.5);
              }
            },
            {
              label: 'Сбросить',
              accelerator: 'CmdOrCtrl+0',
              click: () => {
                mainWindow.webContents.setZoomLevel(0);
              }
            }
          ]
        }
      ]
    },
    {
      label: 'Справка',
      submenu: [
        {
          label: 'Документация',
          click: () => {
            shell.openExternal('https://ghostnet-pro.com/docs');
          }
        },
        {
          label: 'Поддержка',
          click: () => {
            shell.openExternal('https://ghostnet-pro.com/support');
          }
        },
        { type: 'separator' },
        {
          label: 'Консоль разработчика',
          accelerator: process.platform === 'darwin' ? 'Alt+Cmd+I' : 'Ctrl+Shift+I',
          click: () => {
            mainWindow.webContents.toggleDevTools();
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// Готовность приложения
app.whenReady().then(() => {
  createWindow();
  createMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Закрытие всех окон
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Обработка IPC сообщений
ipcMain.handle('app-version', () => {
  return app.getVersion();
});

ipcMain.handle('platform', () => {
  return process.platform;
});

// Обработка уведомлений
ipcMain.handle('show-notification', (event, title, body) => {
  const { Notification } = require('electron');
  
  if (Notification.isSupported()) {
    const notification = new Notification({
      title: title,
      body: body,
      icon: path.join(__dirname, 'assets', 'icon.png')
    });
    
    notification.show();
    return true;
  }
  return false;
});

// Автообновления (в будущем)
app.on('ready', () => {
  // Здесь можно добавить автообновления
  console.log('GhostNet Pro запущен');
});