const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const isDev = false; // Поставь true для разработки

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false
    },
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#000000',
    show: false,
    autoHideMenuBar: true,
    titleBarStyle: 'default'
  });

  // Загружаем HTML файл вместо URL
  mainWindow.loadFile('index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Открываем внешние ссылки в браузере
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// Создаем меню
function createMenu() {
  const template = [
    {
      label: 'GhostNet Pro',
      submenu: [
        {
          label: 'О программе',
          click: () => {
            shell.openExternal('https://ghostnet-pro.com');
          }
        },
        { type: 'separator' },
        {
          label: 'Выход',
          accelerator: 'Ctrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'Защита',
      submenu: [
        {
          label: 'Быстрое подключение VPN',
          accelerator: 'Ctrl+V',
          click: () => {
            mainWindow.webContents.executeJavaScript(`
              // Включаем VPN через JavaScript
              if (typeof handleToggle === 'function') {
                handleToggle('vpnConnection', false, () => {});
              }
            `);
          }
        },
        {
          label: 'Сканирование безопасности',
          accelerator: 'Ctrl+S',
          click: () => {
            mainWindow.webContents.executeJavaScript(`
              // Запускаем сканирование
              if (typeof handleScan === 'function') {
                handleScan();
              }
            `);
          }
        }
      ]
    },
    {
      label: 'Вид',
      submenu: [
        {
          label: 'Обновить',
          accelerator: 'Ctrl+R',
          click: () => {
            mainWindow.reload();
          }
        },
        {
          label: 'Полный экран',
          accelerator: 'F11',
          click: () => {
            mainWindow.setFullScreen(!mainWindow.isFullScreen());
          }
        },
        {
          label: 'Консоль разработчика',
          accelerator: 'Ctrl+Shift+I',
          click: () => {
            mainWindow.webContents.toggleDevTools();
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(() => {
  createWindow();
  createMenu();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});