export async function GET(request) {
  try {
    // Get real IP address
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    
    return Response.json({
      success: true,
      ip: data.ip,
      location: 'Unknown',
      isp: 'Unknown'
    });
  } catch (error) {
    // Fallback IP if service is unavailable
    return Response.json({
      success: true,
      ip: '185.25.12.5',
      location: 'Unknown',
      isp: 'Unknown'
    });
  }
}