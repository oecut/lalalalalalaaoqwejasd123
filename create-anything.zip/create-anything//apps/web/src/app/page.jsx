import React, { useState, useEffect, useRef } from 'react';
import { Shield, Eye, EyeOff, Wifi, Lock, Globe, Zap, Activity, Settings, AlertTriangle, CheckCircle, X } from 'lucide-react';

export default function PrivacyControlPanel() {
  const [ipHiding, setIpHiding] = useState(false);
  const [dnsProtection, setDnsProtection] = useState(false);
  const [trackerBlocking, setTrackerBlocking] = useState(false);
  const [secureMode, setSecureMode] = useState(false);
  const [vpnConnection, setVpnConnection] = useState(false);
  const [adBlocking, setAdBlocking] = useState(false);
  const [currentIp, setCurrentIp] = useState('185.25.12.5');
  const [realIp, setRealIp] = useState('185.25.12.5');
  const [connectionTime, setConnectionTime] = useState('00:00:00');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState([]);
  const [threatsBlocked, setThreatsBlocked] = useState(1247);
  const [isLoading, setIsLoading] = useState(false);
  const [notifications, setNotifications] = useState([]);

  const canvasRef = useRef(null);
  const particlesRef = useRef([]);

  // Particles animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Create particles
    for (let i = 0; i < 50; i++) {
      particlesRef.current.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 3 + 1,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        opacity: Math.random() * 0.5 + 0.2,
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particlesRef.current.forEach(particle => {
        particle.x += particle.speedX;
        particle.y += particle.speedY;

        if (particle.x < 0 || particle.x > canvas.width) particle.speedX *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.speedY *= -1;

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 212, 255, ${particle.opacity})`;
        ctx.fill();
      });

      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Timer for VPN connection
  useEffect(() => {
    let interval;
    if (vpnConnection) {
      interval = setInterval(() => {
        setConnectionTime(prev => {
          const [hours, minutes, seconds] = prev.split(':').map(Number);
          const totalSeconds = hours * 3600 + minutes * 60 + seconds + 1;
          const newHours = Math.floor(totalSeconds / 3600);
          const newMinutes = Math.floor((totalSeconds % 3600) / 60);
          const newSeconds = totalSeconds % 60;
          return `${newHours.toString().padStart(2, '0')}:${newMinutes.toString().padStart(2, '0')}:${newSeconds.toString().padStart(2, '0')}`;
        });
      }, 1000);
    } else {
      setConnectionTime('00:00:00');
    }
    return () => clearInterval(interval);
  }, [vpnConnection]);

  // Get real IP on load
  useEffect(() => {
    fetch('/api/privacy/get-ip')
      .then(res => res.json())
      .then(data => {
        setRealIp(data.ip);
        setCurrentIp(data.ip);
      })
      .catch(err => console.error('Failed to get IP:', err));
  }, []);

  const addNotification = (message, type = 'success') => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  const handleToggle = async (feature, currentState, setter) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/privacy/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feature, enabled: !currentState }),
      });
      
      const data = await response.json();
      
      if (data.success) {
        setter(!currentState);
        
        if (feature === 'ipHiding') {
          setCurrentIp(!currentState ? '***.***.***' : realIp);
        }
        
        if (feature === 'trackerBlocking' && !currentState) {
          setThreatsBlocked(prev => prev + Math.floor(Math.random() * 10) + 1);
        }
        
        addNotification(`${feature} ${!currentState ? 'включен' : 'отключен'}`, 'success');
      } else {
        addNotification('Ошибка подключения', 'error');
      }
    } catch (error) {
      addNotification('Ошибка сети', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleScan = async () => {
    setIsScanning(true);
    setScanResults([]);
    
    const scanSteps = [
      'Проверка DNS утечек...',
      'Анализ WebRTC...',
      'Сканирование портов...',
      'Проверка отпечатков браузера...',
      'Анализ трафика...',
      'Проверка VPN туннеля...'
    ];

    for (let i = 0; i < scanSteps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 500));
      setScanResults(prev => [...prev, { 
        step: scanSteps[i], 
        status: Math.random() > 0.2 ? 'safe' : 'warning',
        details: Math.random() > 0.2 ? 'Защищено' : 'Обнаружена уязвимость'
      }]);
    }

    try {
      const response = await fetch('/api/privacy/security-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      const data = await response.json();
      addNotification(`Сканирование завершено. Найдено угроз: ${data.threatsFound}`, 'success');
    } catch (error) {
      addNotification('Ошибка сканирования', 'error');
    } finally {
      setIsScanning(false);
    }
  };

  const ToggleSwitch = ({ label, icon: Icon, enabled, onToggle, color = '#00D4FF', loading = false }) => (
    <div className="group relative">
      <div className="bg-gradient-to-r from-gray-900/50 to-gray-800/30 rounded-2xl p-6 border border-gray-700/50 hover:border-gray-600/50 transition-all duration-500 hover:shadow-lg hover:shadow-blue-500/20 backdrop-blur-sm transform hover:scale-105 hover:-translate-y-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className={`p-3 rounded-xl ${enabled ? 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20' : 'bg-gray-700/50'} transition-all duration-500 ${enabled ? 'animate-pulse-glow' : ''}`}>
              <Icon size={24} color={enabled ? color : '#6B7280'} className={`transition-all duration-300 ${enabled ? 'animate-spin-slow' : ''}`} />
            </div>
            <div>
              <h3 className="text-white font-semibold text-lg">{label}</h3>
              <p className={`text-sm transition-all duration-300 ${enabled ? 'text-green-400' : 'text-gray-400'}`}>
                {enabled ? 'Активно' : 'Неактивно'}
              </p>
            </div>
          </div>
          
          <div 
            className={`relative w-16 h-8 rounded-full cursor-pointer transition-all duration-500 ${
              enabled ? 'bg-gradient-to-r from-blue-500 to-cyan-400 shadow-lg shadow-blue-500/50' : 'bg-gray-600'
            } ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:scale-110'}`}
            onClick={() => !loading && onToggle()}
          >
            <div 
              className={`absolute w-6 h-6 bg-white rounded-full top-1 transition-all duration-500 shadow-lg ${
                enabled ? 'left-9 shadow-blue-500/30' : 'left-1'
              }`}
            />
            {enabled && (
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-400/30 to-cyan-300/30 animate-pulse-fast" />
            )}
            {loading && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const StatusCard = ({ title, value, icon: Icon, color = '#00D4FF', trend }) => (
    <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/40 rounded-2xl p-6 border border-gray-700/50 backdrop-blur-sm hover:border-gray-600/50 transition-all duration-500 hover:shadow-lg hover:shadow-blue-500/10 transform hover:scale-105 hover:-translate-y-1 group">
      <div className="flex items-center space-x-4">
        <div className="p-3 rounded-xl bg-gradient-to-r from-blue-500/20 to-cyan-500/20 group-hover:from-blue-500/30 group-hover:to-cyan-500/30 transition-all duration-300">
          <Icon size={24} color={color} className="group-hover:animate-bounce" />
        </div>
        <div>
          <p className="text-gray-400 text-sm">{title}</p>
          <p className="text-white font-bold text-xl animate-number-change">{value}</p>
          {trend && (
            <p className={`text-xs ${trend > 0 ? 'text-green-400' : 'text-red-400'}`}>
              {trend > 0 ? '↗' : '↘'} {Math.abs(trend)}%
            </p>
          )}
        </div>
      </div>
    </div>
  );

  const Notification = ({ notification }) => (
    <div className={`fixed top-4 right-4 z-50 p-4 rounded-xl border backdrop-blur-sm transform transition-all duration-500 ${
      notification.type === 'success' 
        ? 'bg-green-500/10 border-green-500/30 text-green-400' 
        : 'bg-red-500/10 border-red-500/30 text-red-400'
    } animate-slide-in`}>
      <div className="flex items-center space-x-3">
        {notification.type === 'success' ? <CheckCircle size={20} /> : <AlertTriangle size={20} />}
        <span>{notification.message}</span>
        <button 
          onClick={() => setNotifications(prev => prev.filter(n => n.id !== notification.id))}
          className="ml-2 hover:scale-110 transition-transform"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative overflow-hidden">
      {/* Animated Canvas Background */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ zIndex: 1 }}
      />

      {/* Animated Background Elements */}
      <div className="absolute inset-0" style={{ zIndex: 1 }}>
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float-delayed" />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl animate-float-slow" />
        <div className="absolute top-10 right-1/3 w-48 h-48 bg-green-500/10 rounded-full blur-3xl animate-bounce-slow" />
        <div className="absolute bottom-10 left-1/3 w-56 h-56 bg-pink-500/10 rounded-full blur-3xl animate-pulse-glow" />
      </div>

      {/* Matrix-style Grid */}
      <div className="absolute inset-0 opacity-10" style={{ zIndex: 1 }}>
        <div className="w-full h-full animate-matrix-rain" style={{
          backgroundImage: `
            linear-gradient(rgba(0,255,0,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,255,0,0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }} />
      </div>

      {/* Notifications */}
      {notifications.map(notification => (
        <Notification key={notification.id} notification={notification} />
      ))}

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-12 animate-slide-down">
          <div className="flex items-center space-x-4">
            <div className="p-4 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-2xl shadow-lg shadow-blue-500/25 animate-glow-pulse">
              <Shield size={32} color="white" className="animate-shield-pulse" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent animate-text-glow">
                GhostNet Pro
              </h1>
              <p className="text-gray-400 animate-fade-in">Максимальная анонимность и защита</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="p-3 bg-gray-800/50 rounded-xl border border-gray-700/50 hover:border-gray-600/50 transition-all duration-300 hover:scale-110 hover:rotate-180">
              <Settings size={20} color="#6B7280" />
            </button>
            <div className={`px-4 py-2 rounded-xl flex items-center space-x-2 transition-all duration-500 ${
              vpnConnection ? 'bg-green-500/20 border border-green-500/30 animate-pulse-green' : 'bg-red-500/20 border border-red-500/30 animate-pulse-red'
            }`}>
              <div className={`w-2 h-2 rounded-full ${vpnConnection ? 'bg-green-400' : 'bg-red-400'} animate-pulse`} />
              <span className="text-sm font-medium">
                {vpnConnection ? 'Защищено' : 'Уязвимо'}
              </span>
            </div>
          </div>
        </div>

        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12 animate-stagger-in">
          <StatusCard 
            title="Ваш IP адрес" 
            value={currentIp} 
            icon={Globe}
            color={ipHiding ? '#10B981' : '#EF4444'}
            trend={ipHiding ? 15 : -10}
          />
          <StatusCard 
            title="Время подключения" 
            value={connectionTime} 
            icon={Activity}
            color="#00D4FF"
          />
          <StatusCard 
            title="Статус VPN" 
            value={vpnConnection ? 'Активен' : 'Отключен'} 
            icon={Wifi}
            color={vpnConnection ? '#10B981' : '#6B7280'}
            trend={vpnConnection ? 25 : -15}
          />
          <StatusCard 
            title="Заблокировано угроз" 
            value={threatsBlocked.toLocaleString()} 
            icon={Shield}
            color="#F59E0B"
            trend={8}
          />
        </div>

        {/* Main Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12 animate-slide-up">
          {/* Privacy Controls */}
          <div className="animate-fade-in-left">
            <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent animate-text-shimmer">
              Контроль приватности
            </h2>
            <div className="space-y-4">
              <ToggleSwitch 
                label="Скрытие IP адреса"
                icon={EyeOff}
                enabled={ipHiding}
                onToggle={() => handleToggle('ipHiding', ipHiding, setIpHiding)}
                color="#10B981"
                loading={isLoading}
              />
              <ToggleSwitch 
                label="DNS защита"
                icon={Shield}
                enabled={dnsProtection}
                onToggle={() => handleToggle('dnsProtection', dnsProtection, setDnsProtection)}
                color="#3B82F6"
                loading={isLoading}
              />
              <ToggleSwitch 
                label="Блокировка трекеров"
                icon={Eye}
                enabled={trackerBlocking}
                onToggle={() => handleToggle('trackerBlocking', trackerBlocking, setTrackerBlocking)}
                color="#8B5CF6"
                loading={isLoading}
              />
            </div>
          </div>

          {/* Security Controls */}
          <div className="animate-fade-in-right">
            <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-300 bg-clip-text text-transparent animate-text-shimmer">
              Контроль безопасности
            </h2>
            <div className="space-y-4">
              <ToggleSwitch 
                label="VPN подключение"
                icon={Wifi}
                enabled={vpnConnection}
                onToggle={() => handleToggle('vpnConnection', vpnConnection, setVpnConnection)}
                color="#06B6D4"
                loading={isLoading}
              />
              <ToggleSwitch 
                label="Блокировка рекламы"
                icon={Zap}
                enabled={adBlocking}
                onToggle={() => handleToggle('adBlocking', adBlocking, setAdBlocking)}
                color="#F59E0B"
                loading={isLoading}
              />
              <ToggleSwitch 
                label="Режим призрака"
                icon={Lock}
                enabled={secureMode}
                onToggle={() => handleToggle('secureMode', secureMode, setSecureMode)}
                color="#EF4444"
                loading={isLoading}
              />
            </div>
          </div>
        </div>

        {/* Security Scan */}
        <div className="bg-gradient-to-r from-gray-900/50 to-gray-800/30 rounded-2xl p-8 border border-gray-700/50 backdrop-blur-sm animate-fade-in-up hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-500">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold mb-2 animate-text-glow">Сканирование безопасности</h3>
              <p className="text-gray-400">Проверка на утечки и уязвимости</p>
            </div>
            <button 
              onClick={handleScan}
              disabled={isScanning}
              className="px-8 py-4 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-xl font-semibold text-white hover:from-blue-600 hover:to-cyan-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-500/25 hover:scale-105 hover:shadow-blue-500/40 animate-button-glow"
            >
              {isScanning ? 'Сканирование...' : 'Запустить сканирование'}
            </button>
          </div>
          
          {isScanning && (
            <div className="relative animate-fade-in">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-8 h-8 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin-fast" />
                <span className="text-blue-400 font-medium animate-pulse">Проверка системы на уязвимости...</span>
              </div>
              <div className="w-full bg-gray-700/50 rounded-full h-2 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full animate-progress-bar" />
              </div>
            </div>
          )}

          {scanResults.length > 0 && (
            <div className="mt-6 space-y-2 animate-fade-in">
              {scanResults.map((result, index) => (
                <div key={index} className={`flex items-center justify-between p-3 rounded-lg border transition-all duration-300 ${
                  result.status === 'safe' 
                    ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                    : 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400'
                } animate-slide-in-scan`} style={{ animationDelay: `${index * 100}ms` }}>
                  <span>{result.step}</span>
                  <span className="text-sm">{result.details}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <style jsx global>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          33% { transform: translateY(-20px) rotate(1deg); }
          66% { transform: translateY(-10px) rotate(-1deg); }
        }
        
        @keyframes float-delayed {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          33% { transform: translateY(-30px) rotate(-1deg); }
          66% { transform: translateY(-15px) rotate(1deg); }
        }
        
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); }
          50% { transform: translateY(-25px) rotate(2deg) scale(1.05); }
        }
        
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-40px); }
        }
        
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 20px rgba(0, 212, 255, 0.3), 0 0 40px rgba(0, 212, 255, 0.1); }
          50% { box-shadow: 0 0 30px rgba(0, 212, 255, 0.6), 0 0 60px rgba(0, 212, 255, 0.2); }
        }
        
        @keyframes glow-pulse {
          0%, 100% { box-shadow: 0 0 20px rgba(59, 130, 246, 0.5); }
          50% { box-shadow: 0 0 40px rgba(59, 130, 246, 0.8), 0 0 60px rgba(59, 130, 246, 0.3); }
        }
        
        @keyframes pulse-fast {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        
        @keyframes pulse-green {
          0%, 100% { box-shadow: 0 0 10px rgba(34, 197, 94, 0.3); }
          50% { box-shadow: 0 0 20px rgba(34, 197, 94, 0.6); }
        }
        
        @keyframes pulse-red {
          0%, 100% { box-shadow: 0 0 10px rgba(239, 68, 68, 0.3); }
          50% { box-shadow: 0 0 20px rgba(239, 68, 68, 0.6); }
        }
        
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        @keyframes spin-fast {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        @keyframes text-glow {
          0%, 100% { text-shadow: 0 0 10px rgba(0, 212, 255, 0.5); }
          50% { text-shadow: 0 0 20px rgba(0, 212, 255, 0.8), 0 0 30px rgba(0, 212, 255, 0.3); }
        }
        
        @keyframes text-shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        
        @keyframes matrix-rain {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100vh); }
        }
        
        @keyframes slide-in {
          from { transform: translateX(100%) scale(0.8); opacity: 0; }
          to { transform: translateX(0) scale(1); opacity: 1; }
        }
        
        @keyframes slide-down {
          from { transform: translateY(-50px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes slide-up {
          from { transform: translateY(50px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes fade-in-left {
          from { transform: translateX(-50px); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes fade-in-right {
          from { transform: translateX(50px); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes fade-in-up {
          from { transform: translateY(30px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes stagger-in {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes progress-bar {
          from { width: 0%; }
          to { width: 100%; }
        }
        
        @keyframes slide-in-scan {
          from { transform: translateX(-20px); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes shield-pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }
        
        @keyframes button-glow {
          0%, 100% { box-shadow: 0 4px 15px rgba(59, 130, 246, 0.25); }
          50% { box-shadow: 0 6px 25px rgba(59, 130, 246, 0.4); }
        }
        
        @keyframes number-change {
          from { transform: scale(1.2); }
          to { transform: scale(1); }
        }
        
        .animate-float { animation: float 6s ease-in-out infinite; }
        .animate-float-delayed { animation: float-delayed 8s ease-in-out infinite; }
        .animate-float-slow { animation: float-slow 10s ease-in-out infinite; }
        .animate-bounce-slow { animation: bounce-slow 4s ease-in-out infinite; }
        .animate-pulse-glow { animation: pulse-glow 2s ease-in-out infinite; }
        .animate-glow-pulse { animation: glow-pulse 2s ease-in-out infinite; }
        .animate-pulse-fast { animation: pulse-fast 1s ease-in-out infinite; }
        .animate-pulse-green { animation: pulse-green 2s ease-in-out infinite; }
        .animate-pulse-red { animation: pulse-red 2s ease-in-out infinite; }
        .animate-spin-slow { animation: spin-slow 3s linear infinite; }
        .animate-spin-fast { animation: spin-fast 1s linear infinite; }
        .animate-text-glow { animation: text-glow 2s ease-in-out infinite; }
        .animate-text-shimmer { 
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent);
          background-size: 200% 100%;
          animation: text-shimmer 3s ease-in-out infinite;
        }
        .animate-matrix-rain { animation: matrix-rain 20s linear infinite; }
        .animate-slide-in { animation: slide-in 0.5s ease-out; }
        .animate-slide-down { animation: slide-down 0.8s ease-out; }
        .animate-slide-up { animation: slide-up 0.8s ease-out; }
        .animate-fade-in-left { animation: fade-in-left 1s ease-out; }
        .animate-fade-in-right { animation: fade-in-right 1s ease-out; }
        .animate-fade-in-up { animation: fade-in-up 0.8s ease-out; }
        .animate-fade-in { animation: fade-in 0.5s ease-out; }
        .animate-stagger-in { animation: stagger-in 0.8s ease-out; }
        .animate-progress-bar { animation: progress-bar 3s ease-out; }
        .animate-slide-in-scan { animation: slide-in-scan 0.3s ease-out; }
        .animate-shield-pulse { animation: shield-pulse 2s ease-in-out infinite; }
        .animate-button-glow { animation: button-glow 2s ease-in-out infinite; }
        .animate-number-change { animation: number-change 0.3s ease-out; }
      `}</style>
    </div>
  );
}