import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const SkillsSection = () => {
  const [ref, inView] = useInView({
    threshold: 0.3,
    triggerOnce: true,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  };

  const skills = [
    {
      icon: "fab fa-html5",
      name: "HTML5",
      description: "Semantic markup",
      delay: 0
    },
    {
      icon: "fab fa-css3-alt",
      name: "CSS3",
      description: "Modern styling",
      delay: 0.1
    },
    {
      icon: "fab fa-js",
      name: "JavaScript",
      description: "ES6+ features",
      delay: 0.2
    },
    {
      icon: "fab fa-react",
      name: "React",
      description: "Component-based",
      delay: 0.3
    },
    {
      icon: "fab fa-git-alt",
      name: "Git",
      description: "Version control",
      delay: 0.4
    },
    {
      icon: "fab fa-figma",
      name: "Figma",
      description: "UI/UX design",
      delay: 0.5
    },
    {
      icon: "fas fa-mobile-alt",
      name: "Responsive",
      description: "Mobile-first",
      delay: 0.6
    },
    {
      icon: "fas fa-rocket",
      name: "Performance",
      description: "Optimization",
      delay: 0.7
    }
  ];

  return (
    <section id="skills" className="min-h-screen flex items-center justify-center py-20" ref={ref}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          <motion.h2 
            className="text-5xl md:text-6xl font-bold mb-8 text-glow-rainbow animate-crazy-spin" 
            variants={itemVariants}
            animate={{
              textShadow: [
                "0 0 20px rgba(255,255,255,1), 0 0 40px rgba(255,255,255,0.8), 0 0 60px rgba(255,255,255,0.4)",
                "0 0 30px rgba(255,255,255,1), 0 0 60px rgba(255,255,255,1), 0 0 90px rgba(255,255,255,0.6)"
              ],
              scale: [1, 1.03],
              y: [0, -8]
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            data-testid="skills-title"
          >
            Skills & Technologies
          </motion.h2>
          <motion.div 
            className="w-24 h-1 bg-white mx-auto rounded-full" 
            variants={itemVariants}
          />
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-6"
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
          >
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                className="skill-badge rounded-xl p-6 text-center"
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.15, 
                  rotate: [0, -3, 3, 0],
                  y: -10,
                  boxShadow: "0 20px 40px rgba(255,255,255,0.3)",
                  borderWidth: "2px",
                  borderColor: "rgba(255,255,255,0.6)",
                  transition: { type: "spring", stiffness: 300 }
                }}
                animate={{
                  y: [0, -5, 0],
                  rotate: [0, 1, -1, 0],
                  scale: [1, 1.02, 1],
                  boxShadow: [
                    "0 5px 15px rgba(255,255,255,0.1)",
                    "0 10px 25px rgba(255,255,255,0.2)",
                    "0 5px 15px rgba(255,255,255,0.1)"
                  ]
                }}
                transition={{
                  duration: 3 + index * 0.2,
                  repeat: Infinity,
                  delay: skill.delay * 2,
                  ease: "easeInOut"
                }}
                data-testid={`skill-${skill.name.toLowerCase()}`}
              >
                <motion.div
                  animate={{ 
                    y: [0, -12, 0],
                    rotate: [0, 5, -5, 0],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    duration: 2.5 + skill.delay, 
                    repeat: Infinity, 
                    delay: skill.delay * 1.5,
                    ease: "easeInOut"
                  }}
                >
                  <motion.i 
                    className={`${skill.icon} text-4xl mb-4`}
                    animate={{
                      rotate: [0, 360],
                      textShadow: [
                        "0 0 0px rgba(255,255,255,0.5)",
                        "0 0 20px rgba(255,255,255,0.9)",
                        "0 0 0px rgba(255,255,255,0.5)"
                      ]
                    }}
                    transition={{
                      rotate: {
                        duration: 8 + index,
                        repeat: Infinity,
                        ease: "linear"
                      },
                      textShadow: {
                        duration: 3,
                        repeat: Infinity,
                        delay: skill.delay
                      }
                    }}
                  ></motion.i>
                </motion.div>
                
                <motion.h3 
                  className="font-semibold" 
                  data-testid={`skill-name-${skill.name.toLowerCase()}`}
                  animate={{
                    textShadow: [
                      "0 0 0px rgba(255,255,255,0.8)",
                      "0 0 10px rgba(255,255,255,1)",
                      "0 0 0px rgba(255,255,255,0.8)"
                    ],
                    scale: [1, 1.05, 1]
                  }}
                  transition={{ 
                    duration: 4, 
                    repeat: Infinity, 
                    delay: skill.delay * 3
                  }}
                >
                  {skill.name}
                </motion.h3>
                <motion.p 
                  className="text-sm text-muted-foreground mt-2" 
                  data-testid={`skill-description-${skill.name.toLowerCase()}`}
                  animate={{
                    opacity: [0.7, 1, 0.7]
                  }}
                  transition={{ 
                    duration: 3, 
                    repeat: Infinity, 
                    delay: skill.delay * 4
                  }}
                >
                  {skill.description}
                </motion.p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
