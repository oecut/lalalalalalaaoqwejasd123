# Portfolio Website

## Overview

This is a modern React-based portfolio website showcasing a developer's skills, projects, and contact information. The application features a sleek single-page design with smooth animations, dark theme styling, and responsive navigation. Built with TypeScript, the site includes sections for hero introduction, about information, project showcases, skills display, and contact form functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The application follows a component-based React architecture with TypeScript for type safety. The main structure consists of:

- **Single Page Application (SPA)**: Uses Wouter for lightweight client-side routing
- **Component Organization**: Modular components organized by feature (hero, about, projects, skills, contact, navigation, footer)
- **UI Component Library**: Extensive use of shadcn/ui components built on Radix UI primitives for consistent, accessible design
- **Animation System**: Framer Motion integration for smooth page transitions and interactive animations
- **State Management**: React Query (@tanstack/react-query) for server state management and caching
- **Styling Approach**: Tailwind CSS with CSS variables for theming and dark mode support

### Backend Architecture

The backend uses a Node.js/Express server setup with the following characteristics:

- **API Framework**: Express.js with TypeScript for RESTful API endpoints
- **Development Integration**: Vite development server integration for hot module replacement
- **Storage Abstraction**: Interface-based storage system with in-memory implementation (MemStorage class)
- **Route Organization**: Centralized route registration system in `/api` namespace
- **Error Handling**: Global error handler middleware for consistent error responses

### Database Schema

The application includes a basic user management schema using Drizzle ORM:

- **Users Table**: Contains id (UUID), username (unique), and password fields
- **Schema Validation**: Zod integration for runtime type checking and validation
- **Database Abstraction**: Drizzle ORM with PostgreSQL dialect configuration

### Design System

The project implements a comprehensive design system:

- **Theme System**: Dark-first design with CSS custom properties
- **Component Library**: Full shadcn/ui component suite including forms, dialogs, navigation, and feedback components
- **Typography**: Multiple font families including Inter, Architects Daughter, DM Sans, and Fira Code
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Animation Framework**: Intersection Observer API integration for scroll-triggered animations

### Development Architecture

The project structure supports full-stack development:

- **Monorepo Structure**: Client, server, and shared code organization
- **Build System**: Vite for frontend bundling, esbuild for server compilation
- **Type Safety**: Shared TypeScript types between frontend and backend
- **Development Experience**: Hot reload, error overlays, and development banners for Replit environment

## External Dependencies

### Core Framework Dependencies
- **React 18**: Frontend framework with hooks and context
- **Express**: Backend web framework
- **TypeScript**: Type safety across the entire application
- **Vite**: Build tool and development server

### UI and Animation Libraries
- **Radix UI**: Comprehensive set of accessible React components
- **Framer Motion**: Animation library for React
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Pre-built component library
- **Lucide React**: Icon library

### Data and State Management
- **React Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **Wouter**: Lightweight React router

### Database and ORM
- **Drizzle ORM**: TypeScript ORM for SQL databases
- **Neon Database**: PostgreSQL database service (@neondatabase/serverless)
- **Zod**: Schema validation library

### Development Tools
- **Replit Plugins**: Development banner, cartographer, and error modal for Replit environment
- **PostCSS**: CSS processing with Tailwind and Autoprefixer
- **ESBuild**: Fast JavaScript bundler for production builds

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: Conditional CSS class management
- **nanoid**: Unique ID generation
- **class-variance-authority**: Component variant management