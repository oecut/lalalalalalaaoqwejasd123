# /ErrrorBot/app/services/huggingface_datasets.py

import asyncio
import logging
from typing import List, Dict, Optional
import json
import os

try:
    from datasets import load_dataset
    from huggingface_hub import HfApi, snapshot_download
    HUGGINGFACE_AVAILABLE = True
except ImportError:
    HUGGINGFACE_AVAILABLE = False
    logging.error("HuggingFace библиотеки не установлены")

class HuggingFaceDatasetService:
    """Сервис для работы с датасетами HuggingFace для улучшения качества ответов ИИ"""
    
    def __init__(self):
        self.datasets_cache_dir = "cache/datasets"
        self.loaded_datasets = {}
        self.knowledge_base = []
        
        # Убеждаемся что папка существует
        os.makedirs(self.datasets_cache_dir, exist_ok=True)
        
        if HUGGINGFACE_AVAILABLE:
            print("🤖 HuggingFace Dataset Service инициализирован")
        else:
            print("❌ HuggingFace недоступен")
    
    async def load_finepdfs_dataset(self, sample_size: int = 100) -> bool:
        """
        Загружает датасет finepdfs для улучшения качества ответов
        https://huggingface.co/datasets/HuggingFaceFW/finepdfs
        """
        if not HUGGINGFACE_AVAILABLE:
            return False
        
        try:
            print(f"📚 Загружаем датасет finepdfs (выборка {sample_size} документов)...")
            
            # Загружаем датасет в потоковом режиме для экономии памяти
            dataset = await asyncio.to_thread(
                load_dataset,
                "HuggingFaceFW/finepdfs", 
                split="train",
                streaming=True,
                cache_dir=self.datasets_cache_dir
            )
            
            # Извлекаем ограниченное количество документов в потоковом режиме
            documents = []
            count = 0
            for item in dataset:
                if count >= sample_size:
                    break
                if 'text' in item and item['text']:
                    # Берем только первые 1500 символов каждого документа
                    text = item['text'][:1500]
                    if len(text) > 100:  # Фильтруем слишком короткие тексты
                        documents.append(text)
                        count += 1
            
            self.loaded_datasets['finepdfs'] = documents
            self.knowledge_base.extend(documents)
            
            print(f"✅ Загружено {len(documents)} документов из finepdfs")
            return True
            
        except Exception as e:
            logging.error(f"Ошибка загрузки finepdfs: {e}")
            return False
    
    async def load_gdpval_dataset(self, sample_size: int = 500) -> bool:
        """
        Загружает датасет gdpval для экономической информации
        https://huggingface.co/datasets/openai/gdpval
        """
        if not HUGGINGFACE_AVAILABLE:
            return False
        
        try:
            print(f"📈 Загружаем датасет gdpval (выборка {sample_size} записей)...")
            
            # Загружаем датасет
            dataset = await asyncio.to_thread(
                load_dataset,
                "openai/gdpval",
                split=f"train[:{sample_size}]",
                cache_dir=self.datasets_cache_dir
            )
            
            # Извлекаем экономические данные
            economic_data = []
            for item in dataset:
                # Объединяем все доступные текстовые поля
                text_parts = []
                for key, value in item.items():
                    if isinstance(value, str) and len(value) > 10:
                        text_parts.append(f"{key}: {value}")
                
                if text_parts:
                    combined_text = " | ".join(text_parts)
                    if len(combined_text) > 50:
                        economic_data.append(combined_text)
            
            self.loaded_datasets['gdpval'] = economic_data
            self.knowledge_base.extend(economic_data)
            
            print(f"✅ Загружено {len(economic_data)} записей из gdpval")
            return True
            
        except Exception as e:
            logging.error(f"Ошибка загрузки gdpval: {e}")
            return False
    
    def search_relevant_context(self, query: str, max_results: int = 3) -> str:
        """
        Ищет релевантный контекст в загруженных датасетах для улучшения ответа
        """
        if not self.knowledge_base:
            return ""
        
        query_lower = query.lower()
        relevant_docs = []
        
        # Простой поиск по ключевым словам
        for doc in self.knowledge_base:
            doc_lower = doc.lower()
            # Подсчитываем количество совпадений слов
            query_words = set(query_lower.split())
            doc_words = set(doc_lower.split())
            
            # Находим пересечение
            intersection = query_words.intersection(doc_words)
            if len(intersection) > 0:
                relevance_score = len(intersection) / len(query_words)
                relevant_docs.append((doc, relevance_score))
        
        # Сортируем по релевантности
        relevant_docs.sort(key=lambda x: x[1], reverse=True)
        
        # Берем топ результаты
        context_parts = []
        for doc, score in relevant_docs[:max_results]:
            # Обрезаем длинные документы
            short_doc = doc[:500] + ("..." if len(doc) > 500 else "")
            context_parts.append(short_doc)
        
        if context_parts:
            return "Дополнительный контекст из базы знаний:\n" + "\n---\n".join(context_parts)
        
        return ""
    
    def get_enhanced_system_prompt(self, original_prompt: str, user_query: str) -> str:
        """
        Улучшает системный промпт добавлением релевантной информации из датасетов
        """
        context = self.search_relevant_context(user_query)
        
        if context:
            enhanced_prompt = f"{original_prompt}\n\n{context}\n\nИспользуй эту дополнительную информацию для более точного и информативного ответа."
            return enhanced_prompt
        
        return original_prompt
    
    async def initialize_datasets(self) -> bool:
        """
        Инициализирует все датасеты асинхронно
        """
        if not HUGGINGFACE_AVAILABLE:
            print("❌ HuggingFace недоступен, пропускаем загрузку датасетов")
            return False
        
        print("🚀 Начинаем загрузку датасетов...")
        
        # Загружаем датасеты с минимальными выборками для стабильности
        tasks = [
            self.load_finepdfs_dataset(15),   # Очень маленькая выборка в потоковом режиме
            self.load_gdpval_dataset(220)     # Стабильно работающий датасет  
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        success_count = sum(1 for result in results if result is True)
        failed_count = len([result for result in results if isinstance(result, Exception)])
        
        if success_count > 0:
            print(f"✅ Успешно загружено {success_count} из {len(tasks)} датасетов")
            if failed_count > 0:
                print(f"⚠️  Не удалось загрузить {failed_count} датасетов")
            print(f"📊 Общий размер базы знаний: {len(self.knowledge_base)} документов")
            return True
        else:
            print("❌ Не удалось загрузить датасеты")
            return False
    
    def get_stats(self) -> Dict[str, int]:
        """Возвращает статистику по загруженным датасетам"""
        stats = {
            'total_documents': len(self.knowledge_base),
            'loaded_datasets': len(self.loaded_datasets)
        }
        
        for name, data in self.loaded_datasets.items():
            stats[f'{name}_count'] = len(data)
        
        return stats

# Создаем глобальный экземпляр
hf_datasets_service = HuggingFaceDatasetService()