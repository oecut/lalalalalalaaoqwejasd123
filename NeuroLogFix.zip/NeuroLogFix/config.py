# /ErrrorBot/config.py

import os
from dataclasses import dataclass, field
from typing import List

# Получаем токен из переменных окружения (безопаснее)
BOT_TOKEN = os.getenv('BOT_TOKEN')
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN не найден в переменных окружения")

# ID администраторов - можно добавить через переменные окружения или задать по умолчанию
ADMIN_IDS_STR = os.getenv('ADMIN_IDS', '1234')  # Значение по умолчанию
try:
    ADMIN_IDS = [int(id_.strip()) for id_ in ADMIN_IDS_STR.split(',') if id_.strip()]
except ValueError:
    ADMIN_IDS = [1234]  # Значение по умолчанию

@dataclass(frozen=True)
class BotConfig:
    """Конфигурация бота"""
    token: str = BOT_TOKEN
    admin_ids: List[int] = field(default_factory=lambda: ADMIN_IDS)

@dataclass(frozen=True)
class Settings:
    """Общие настройки приложения"""
    daily_request_limit: int = 100
    request_timeout_seconds: int = 10
    # Лимит токенов для генерации (предотвращает слишком длинные ответы)
    max_tokens: int = 1000

# Создаем неизменяемые экземпляры конфигураций для импорта в другие части приложения.
bot_config = BotConfig()
settings = Settings()