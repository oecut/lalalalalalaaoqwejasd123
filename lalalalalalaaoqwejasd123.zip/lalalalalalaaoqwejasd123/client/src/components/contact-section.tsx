import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useToast } from "@/hooks/use-toast";

const ContactSection = () => {
  const [ref, inView] = useInView({
    threshold: 0.3,
    triggerOnce: true,
  });

  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    // Simulate form submission
    toast({
      title: "Message sent!",
      description: "Thank you for your message! I'll get back to you soon.",
    });

    // Reset form
    setFormData({
      name: "",
      email: "",
      message: ""
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  const contactMethods = [
    {
      icon: "fas fa-envelope",
      title: "Email",
      value: "oecut.major@email.com",
      testId: "contact-email"
    },
    {
      icon: "fab fa-github",
      title: "GitHub",
      value: "@oecut_major",
      testId: "contact-github"
    },
    {
      icon: "fab fa-telegram",
      title: "Telegram",
      value: "@oecut_major",
      testId: "contact-telegram"
    }
  ];

  return (
    <section id="contact" className="min-h-screen flex items-center justify-center py-20" ref={ref}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          <motion.h2 
            className="text-5xl md:text-6xl font-bold mb-8 text-glow-intense" 
            variants={itemVariants}
            data-testid="contact-title"
          >
            Get In Touch
          </motion.h2>
          <motion.div 
            className="w-24 h-1 bg-white mx-auto rounded-full" 
            variants={itemVariants}
          />
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
            >
              <motion.h3 
                className="text-3xl font-bold mb-6 text-glow-rainbow" 
                variants={itemVariants}
                data-testid="contact-subtitle"
              >
                Let's Connect
              </motion.h3>
              
              <motion.p 
                className="text-lg text-muted-foreground mb-8" 
                variants={itemVariants}
                data-testid="contact-description"
              >
                Ready to bring your ideas to life? I'm always excited to work on new projects 
                and collaborate with fellow developers and designers.
              </motion.p>
              
              <div className="space-y-6">
                {contactMethods.map((method, index) => (
                  <motion.div
                    key={method.title}
                    className="flex items-center space-x-4 group transition-all duration-300"
                    variants={itemVariants}
                    whileHover={{ 
                      x: 15,
                      scale: 1.08,
                      y: -3
                    }}
                    animate={{
                      x: [0, 3, 0],
                      y: [0, -2, 0]
                    }}
                    transition={{
                      duration: 3 + index * 0.5,
                      repeat: Infinity,
                      delay: index * 0.8
                    }}
                    data-testid={method.testId}
                  >
                    <motion.div 
                      className="w-12 h-12 bg-accent rounded-full flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300"
                      animate={{
                        scale: [1, 1.1, 1],
                        rotate: [0, 5, -5, 0],
                        boxShadow: [
                          "0 0 10px rgba(255,255,255,0.2)",
                          "0 0 20px rgba(255,255,255,0.4)",
                          "0 0 10px rgba(255,255,255,0.2)"
                        ]
                      }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        delay: index * 0.3
                      }}
                      whileHover={{
                        rotate: [0, 360],
                        scale: 1.2
                      }}
                    >
                      <motion.i 
                        className={method.icon}
                        animate={{
                          textShadow: [
                            "0 0 0px rgba(255,255,255,0.5)",
                            "0 0 15px rgba(255,255,255,1)",
                            "0 0 0px rgba(255,255,255,0.5)"
                          ]
                        }}
                        transition={{ duration: 2, repeat: Infinity, delay: index * 0.4 }}
                      ></motion.i>
                    </motion.div>
                    <motion.div
                      animate={{
                        y: [0, -1, 0]
                      }}
                      transition={{ duration: 2.5, repeat: Infinity, delay: index * 0.2 }}
                    >
                      <motion.p 
                        className="font-semibold"
                        animate={{
                          textShadow: [
                            "0 0 0px rgba(255,255,255,0.8)",
                            "0 0 8px rgba(255,255,255,1)",
                            "0 0 0px rgba(255,255,255,0.8)"
                          ]
                        }}
                        transition={{ duration: 3, repeat: Infinity, delay: index * 0.5 }}
                      >
                        {method.title}
                      </motion.p>
                      <p className="text-muted-foreground">{method.value}</p>
                    </motion.div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
            >
              <form className="space-y-6" onSubmit={handleSubmit} data-testid="contact-form">
                <motion.div className="group" variants={itemVariants}>
                  <input 
                    type="text" 
                    name="name"
                    placeholder="Your Name" 
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full bg-accent border border-border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent transition-all duration-300 group-hover:bg-muted"
                    data-testid="input-name"
                  />
                </motion.div>
                
                <motion.div className="group" variants={itemVariants}>
                  <input 
                    type="email" 
                    name="email"
                    placeholder="Your Email" 
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full bg-accent border border-border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent transition-all duration-300 group-hover:bg-muted"
                    data-testid="input-email"
                  />
                </motion.div>
                
                <motion.div className="group" variants={itemVariants}>
                  <textarea 
                    placeholder="Your Message" 
                    name="message"
                    rows={5} 
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full bg-accent border border-border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent transition-all duration-300 group-hover:bg-muted resize-none"
                    data-testid="input-message"
                  />
                </motion.div>
                
                <motion.button 
                  type="submit" 
                  className="w-full bg-white text-black py-3 rounded-lg font-semibold hover:bg-gray-200 transition-all duration-300 glow"
                  variants={itemVariants}
                  whileHover={{ 
                    scale: 1.05,
                    y: -3,
                    boxShadow: "0 15px 30px rgba(255,255,255,0.4)"
                  }}
                  whileTap={{ scale: 0.95 }}
                  animate={{
                    y: [0, -2, 0],
                    boxShadow: [
                      "0 5px 15px rgba(255,255,255,0.2)",
                      "0 10px 25px rgba(255,255,255,0.3)",
                      "0 5px 15px rgba(255,255,255,0.2)"
                    ]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  data-testid="button-send-message"
                >
                  <motion.span
                    animate={{
                      textShadow: [
                        "0 0 0px rgba(0,0,0,0.5)",
                        "0 0 5px rgba(0,0,0,0.8)",
                        "0 0 0px rgba(0,0,0,0.5)"
                      ]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    Send Message
                  </motion.span>
                </motion.button>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
