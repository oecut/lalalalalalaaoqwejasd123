import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const ProjectsSection = () => {
  const [ref, inView] = useInView({
    threshold: 0.3,
    triggerOnce: true,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  const projects = [
    {
      id: "first-project",
      title: "First Project",
      description: "My debut project is currently in development. A modern web application showcasing everything I've learned so far.",
      launchDate: "01.01.2026",
      status: "In Development",
      technologies: ["React", "TypeScript", "Tailwind"],
      icon: "fas fa-rocket",
      active: true
    },
    {
      id: "project-two",
      title: "Project Two",
      description: "An exciting e-commerce platform with modern UI/UX design and smooth animations.",
      status: "In Planning",
      icon: "fas fa-code",
      active: false
    },
    {
      id: "project-three",
      title: "Project Three",
      description: "A responsive web application focusing on mobile-first design and performance.",
      status: "Concept Stage",
      icon: "fas fa-mobile-alt",
      active: false
    }
  ];

  return (
    <section id="projects" className="min-h-screen flex items-center justify-center py-20" ref={ref}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          <motion.h2 
            className="text-5xl md:text-6xl font-bold mb-8 text-glow-intense animate-heartbeat" 
            variants={itemVariants}
            animate={{
              textShadow: [
                "0 0 15px rgba(255,255,255,1), 0 0 30px rgba(255,255,255,0.7), 0 0 45px rgba(255,255,255,0.4)",
                "0 0 25px rgba(255,255,255,1), 0 0 50px rgba(255,255,255,0.9), 0 0 75px rgba(255,255,255,0.6)"
              ],
              y: [0, -5]
            }}
            transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
            data-testid="projects-title"
          >
            Projects
          </motion.h2>
          <motion.div 
            className="w-24 h-1 bg-white mx-auto rounded-full" 
            variants={itemVariants}
          />
        </motion.div>
        
        <div className="max-w-6xl mx-auto">
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
          >
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                className={`project-card rounded-xl p-8 text-center ${!project.active ? 'opacity-60' : ''}`}
                variants={itemVariants}
                whileHover={project.active ? { 
                  y: -15, 
                  scale: 1.05,
                  rotate: [0, -1, 1, 0],
                  boxShadow: "0 25px 50px rgba(255,255,255,0.2)",
                  borderColor: "rgba(255,255,255,0.4)",
                  transition: { type: "spring", stiffness: 300 }
                } : {
                  y: -5,
                  scale: 1.02,
                  transition: { type: "spring", stiffness: 200 }
                }}
                animate={{
                  y: [0, -2],
                  boxShadow: [
                    "0 10px 20px rgba(255,255,255,0.1)",
                    "0 15px 30px rgba(255,255,255,0.15)"
                  ]
                }}
                transition={{
                  duration: 4 + index,
                  repeat: Infinity,
                  delay: index * 0.5
                }}
                data-testid={`project-card-${project.id}`}
              >
                <motion.div 
                  className="mb-6"
                  animate={{
                    y: [0, -8, 0],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{
                    duration: 3 + index * 0.5,
                    repeat: Infinity,
                    delay: index * 0.4
                  }}
                >
                  <motion.i 
                    className={`${project.icon} text-4xl text-white`}
                    animate={{
                      rotate: project.active ? [0, 10, -10, 0] : [0, 5, -5, 0],
                      scale: [1, 1.2, 1],
                      textShadow: [
                        "0 0 5px rgba(255,255,255,0.5)",
                        "0 0 15px rgba(255,255,255,0.8)",
                        "0 0 5px rgba(255,255,255,0.5)"
                      ]
                    }}
                    transition={{
                      duration: project.active ? 2 : 4,
                      repeat: Infinity,
                      delay: index * 0.2
                    }}
                  ></motion.i>
                </motion.div>
                
                <motion.h3 
                  className="text-2xl font-bold mb-4 text-glow-intense float-extreme" 
                  data-testid={`project-title-${project.id}`}
                  animate={{
                    textShadow: [
                      "0 0 10px rgba(255,255,255,0.9), 0 0 20px rgba(255,255,255,0.6)",
                      "0 0 20px rgba(255,255,255,1), 0 0 40px rgba(255,255,255,0.8)",
                      "0 0 10px rgba(255,255,255,0.9), 0 0 20px rgba(255,255,255,0.6)"
                    ],
                    scale: [1, 1.05, 1]
                  }}
                  transition={{
                    duration: 4 + index * 0.5,
                    repeat: Infinity,
                    delay: index * 0.3
                  }}
                >
                  {project.title}
                </motion.h3>
                
                <p className="text-muted-foreground mb-6" data-testid={`project-description-${project.id}`}>
                  {project.description}
                </p>
                
                <div className={`${project.active ? 'bg-accent' : 'bg-muted'} rounded-lg p-4 mb-6`}>
                  <p className="text-sm text-muted-foreground">
                    {project.launchDate ? 'Launch Date' : 'Status'}
                  </p>
                  <p className={`text-xl font-bold ${project.active ? 'text-white' : ''}`} data-testid={`project-status-${project.id}`}>
                    {project.launchDate || project.status}
                  </p>
                </div>
                
                {project.technologies && (
                  <div className="flex flex-wrap gap-2 justify-center">
                    {project.technologies.map((tech) => (
                      <span 
                        key={tech} 
                        className="bg-secondary px-3 py-1 rounded-full text-xs"
                        data-testid={`project-tech-${tech.toLowerCase()}`}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
