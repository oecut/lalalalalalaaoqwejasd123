import { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";

const HeroSection = () => {
  const [displayedText, setDisplayedText] = useState("");
  const [showCursor, setShowCursor] = useState(true);
  const fullText = "@oecut_major";
  
  // Таймер обратного отсчета до 01.01.2026
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const targetDate = new Date('2026-01-01T00:00:00').getTime();

    const updateTimer = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeLeft({ days, hours, minutes, seconds });
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, []);

  const particles = useMemo(() => 
    Array.from({ length: 25 }, (_, i) => ({
      size: Math.random() * 8 + 2,
      left: Math.random() * 100,
      top: Math.random() * 100,
      xMove: Math.random() * 20 - 10,
      scaleTarget: Math.random() * 0.5 + 0.8,
      opacityTarget: Math.random() * 0.4 + 0.2,
      duration: Math.random() * 4 + 3,
      delay: Math.random() * 2
    })), []);

  const extraElements = useMemo(() =>
    Array.from({ length: 15 }, (_, i) => ({
      width: Math.random() * 3 + 1,
      height: Math.random() * 100 + 50,
      left: Math.random() * 100,
      top: Math.random() * 100,
      rotate: Math.random() * 360,
      xMove: Math.random() * 30 - 15,
      scaleY: Math.random() * 2 + 0.5,
      duration: Math.random() * 8 + 5,
      delay: Math.random() * 3
    })), []);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    const typeWriter = () => {
      if (displayedText.length < fullText.length) {
        timeout = setTimeout(() => {
          setDisplayedText(fullText.slice(0, displayedText.length + 1));
        }, 60);
      } else {
        setTimeout(() => {
          setShowCursor(false);
        }, 1000);
      }
    };

    const initialDelay = setTimeout(typeWriter, 300);

    return () => {
      clearTimeout(timeout);
      clearTimeout(initialDelay);
    };
  }, [displayedText, fullText]);

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Супер анимированный фон */}
      <div className="floating-shapes"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black opacity-30"></div>
      
      {/* Движущиеся волны */}
      <motion.div 
        className="absolute inset-0 opacity-20"
        animate={{
          background: [
            'radial-gradient(circle at 0% 0%, rgba(255,255,255,0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 100% 100%, rgba(255,255,255,0.1) 0%, transparent 50%)'
          ]
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "linear"
        }}
      />
      
      {/* Дополнительные летающие элементы */}
      {extraElements.map((element, i) => (
        <motion.div
          key={`extra-${i}`}
          className="absolute bg-gradient-to-r from-white to-transparent opacity-10"
          style={{
            width: element.width + 'px',
            height: element.height + 'px',
            left: element.left + '%',
            top: element.top + '%',
            rotate: element.rotate + 'deg'
          }}
          animate={{
            y: [0, -50],
            x: [0, element.xMove],
            rotate: [0, 360],
            opacity: [0.05, 0.2],
            scaleY: [1, element.scaleY]
          }}
          transition={{
            duration: element.duration,
            repeat: Infinity,
            delay: element.delay,
            ease: "easeInOut"
          }}
        />
      ))}
      
      {/* Animated background particles */}
      {particles.map((particle: any, i: number) => (
        <motion.div
          key={i}
          className="absolute bg-white rounded-full opacity-20"
          style={{
            width: particle.size + 'px',
            height: particle.size + 'px',
            left: particle.left + '%',
            top: particle.top + '%',
          }}
          animate={{
            y: [0, -30],
            x: [0, particle.xMove],
            scale: [1, particle.scaleTarget],
            opacity: [0.1, particle.opacityTarget]
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            delay: particle.delay,
            ease: "easeInOut"
          }}
        />
      ))}

      {/* Floating geometric shapes */}
      <motion.div
        className="absolute top-20 left-10 w-8 h-8 border-2 border-white opacity-20"
        animate={{ 
          rotate: [0, 360],
          scale: [1, 1.2],
          y: [0, -20]
        }}
        transition={{ duration: 8, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-20 right-20 w-6 h-6 bg-white opacity-15"
        style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }}
        animate={{ 
          rotate: [0, -360],
          y: [0, -25],
          x: [0, 10]
        }}
        transition={{ duration: 6, repeat: Infinity, delay: 1 }}
      />
      <motion.div
        className="absolute top-1/3 right-1/4 w-12 h-1 bg-white opacity-25"
        animate={{ 
          rotate: [0, 360],
          scale: [1, 1.5]
        }}
        transition={{ duration: 4, repeat: Infinity, delay: 2 }}
      />

      {/* 3D Objects with Telegram Info */}
      <div className="object-3d-container" style={{ top: '15%', right: '10%' }}>
        <div className="object-3d">
          <div className="object-3d-cube">
            <div className="cube-face cube-front">@</div>
            <div className="cube-face cube-back">🔥</div>
            <div className="cube-face cube-right">💻</div>
            <div className="cube-face cube-left">⚡</div>
            <div className="cube-face cube-top">🚀</div>
            <div className="cube-face cube-bottom">✨</div>
          </div>
        </div>
        <div className="telegram-tooltip">
          <div className="telegram-username">@oecut_major</div>
          <div className="telegram-description">Frontend Developer<br/>Available in Telegram</div>
        </div>
      </div>

      <div className="object-3d-container" style={{ bottom: '20%', left: '15%' }}>
        <div className="object-3d">
          <div className="object-3d-sphere"></div>
        </div>
        <div className="telegram-tooltip">
          <div className="telegram-username">@oecut_major</div>
          <div className="telegram-description">Contact me via Telegram<br/>for collaboration</div>
        </div>
      </div>

      <div className="object-3d-container" style={{ top: '40%', left: '8%' }}>
        <div className="object-3d">
          <div className="object-3d-pyramid"></div>
        </div>
        <div className="telegram-tooltip">
          <div className="telegram-username">@oecut_major</div>
          <div className="telegram-description">Let's build something amazing<br/>together!</div>
        </div>
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <motion.div
          animate={{ 
            y: [0, -10],
            scale: [1, 1.02]
          }}
          transition={{ 
            duration: 4, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
        >
          <motion.h1 
            className="text-6xl md:text-8xl font-bold mb-6 text-glow-intense" 
            data-testid="hero-title"
            whileHover={{ 
              scale: 1.08,
              textShadow: "0 0 50px rgba(255,255,255,1)"
            }}
            animate={{
              textShadow: [
                "0 0 20px rgba(255,255,255,1), 0 0 40px rgba(255,255,255,0.8), 0 0 60px rgba(255,255,255,0.5)",
                "0 0 30px rgba(255,255,255,1), 0 0 60px rgba(255,255,255,1), 0 0 90px rgba(255,255,255,0.7)"
              ],
              scale: [1, 1.02]
            }}
            transition={{ 
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <motion.span 
              className="gradient-text"
              animate={{ 
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              {displayedText}
              {showCursor && (
                <motion.span 
                  className="typewriter-cursor"
                  animate={{ opacity: [1, 0] }}
                  transition={{ duration: 0.8, repeat: Infinity }}
                >
                  |
                </motion.span>
              )}
            </motion.span>
          </motion.h1>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4, duration: 0.8 }}
        >
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 font-light" data-testid="hero-subtitle">
            Frontend Developer in Training
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4.5, duration: 0.8 }}
        >
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto" data-testid="hero-description">
            Crafting beautiful digital experiences with code. Currently mastering the art of frontend development.
          </p>
        </motion.div>

        {/* Таймер обратного отсчета до проекта */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 4.8, duration: 1 }}
          className="mb-8"
        >
          <div className="bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 max-w-lg mx-auto glow-border">
            <h3 className="text-xl font-bold mb-4 text-center text-glow">🚀 Мой проект выйдет через:</h3>
            <div className="grid grid-cols-4 gap-4 text-center">
              <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-3xl font-bold text-glow-intense">{timeLeft.days}</div>
                <div className="text-sm text-muted-foreground">Дней</div>
              </div>
              <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-3xl font-bold text-glow-intense">{timeLeft.hours}</div>
                <div className="text-sm text-muted-foreground">Часов</div>
              </div>
              <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-3xl font-bold text-glow-intense">{timeLeft.minutes}</div>
                <div className="text-sm text-muted-foreground">Минут</div>
              </div>
              <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-3xl font-bold text-glow-intense">{timeLeft.seconds}</div>
                <div className="text-sm text-muted-foreground">Секунд</div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* 3D фигура */}
        <motion.div
          initial={{ opacity: 0, rotateY: -180 }}
          animate={{ opacity: 1, rotateY: 0 }}
          transition={{ delay: 5.2, duration: 1.5 }}
          className="mb-8 flex justify-center"
        >
          <div className="cube-container perspective-1000">
            <motion.div 
              className="cube-3d transform-style-preserve-3d"
              animate={{ 
                rotateX: [0, 360],
                rotateY: [0, 360],
                rotateZ: [0, 180]
              }}
              transition={{ 
                duration: 20,
                repeat: Infinity,
                ease: "linear"
              }}
            >
              <div className="cube-face cube-front">🎯</div>
              <div className="cube-face cube-back">💻</div>
              <div className="cube-face cube-right">🚀</div>
              <div className="cube-face cube-left">⭐</div>
              <div className="cube-face cube-top">🔥</div>
              <div className="cube-face cube-bottom">💡</div>
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 5.5, duration: 0.8 }}
        >
          <motion.button 
            onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
            className="inline-block bg-white text-black px-8 py-4 rounded-full font-semibold hover:bg-gray-200 transition-all duration-300 glow"
            data-testid="button-discover-journey"
            whileHover={{ 
              scale: 1.1,
              boxShadow: "0 0 30px rgba(255,255,255,0.8)",
            }}
            whileTap={{ scale: 0.95 }}
          >
            <span>Discover My Journey</span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
