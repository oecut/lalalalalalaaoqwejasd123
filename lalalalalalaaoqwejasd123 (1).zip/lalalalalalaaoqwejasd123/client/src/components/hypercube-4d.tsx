import { useState } from "react";
import { motion } from "framer-motion";

const Hypercube4D = () => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="relative flex justify-center items-center">
      {/* 4D Hypercube Container */}
      <motion.div
        className="relative perspective-1000 cursor-pointer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        whileHover={{ scale: 1.1 }}
        transition={{ duration: 0.3 }}
      >
        {/* Outer Cube */}
        <motion.div
          className="hypercube-outer transform-style-preserve-3d relative"
          animate={{ 
            rotateX: [0, 360],
            rotateY: [0, 360],
            rotateZ: [0, 180]
          }}
          transition={{ 
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
        >
          {/* Outer cube faces */}
          <div className="hypercube-face hypercube-front-outer">
            <div className="hypercube-inner-grid">
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
            </div>
          </div>
          <div className="hypercube-face hypercube-back-outer">
            <div className="hypercube-inner-grid">
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
            </div>
          </div>
          <div className="hypercube-face hypercube-right-outer">
            <div className="hypercube-inner-grid">
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
            </div>
          </div>
          <div className="hypercube-face hypercube-left-outer">
            <div className="hypercube-inner-grid">
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
            </div>
          </div>
          <div className="hypercube-face hypercube-top-outer">
            <div className="hypercube-inner-grid">
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
            </div>
          </div>
          <div className="hypercube-face hypercube-bottom-outer">
            <div className="hypercube-inner-grid">
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
              <div className="grid-cell"></div>
            </div>
          </div>

          {/* Inner Cube (4th dimension projection) */}
          <motion.div
            className="hypercube-inner transform-style-preserve-3d absolute"
            animate={{ 
              rotateX: [360, 0],
              rotateY: [360, 0],
              rotateZ: [180, 0]
            }}
            transition={{ 
              duration: 25,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            <div className="hypercube-face hypercube-front-inner">
              <div className="hypercube-inner-grid">
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
              </div>
            </div>
            <div className="hypercube-face hypercube-back-inner">
              <div className="hypercube-inner-grid">
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
              </div>
            </div>
            <div className="hypercube-face hypercube-right-inner">
              <div className="hypercube-inner-grid">
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
              </div>
            </div>
            <div className="hypercube-face hypercube-left-inner">
              <div className="hypercube-inner-grid">
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
              </div>
            </div>
            <div className="hypercube-face hypercube-top-inner">
              <div className="hypercube-inner-grid">
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
              </div>
            </div>
            <div className="hypercube-face hypercube-bottom-inner">
              <div className="hypercube-inner-grid">
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
                <div className="grid-cell"></div>
              </div>
            </div>
          </motion.div>

          {/* Connection lines between outer and inner cubes */}
          <div className="hypercube-connections">
            <div className="connection-line connection-1"></div>
            <div className="connection-line connection-2"></div>
            <div className="connection-line connection-3"></div>
            <div className="connection-line connection-4"></div>
            <div className="connection-line connection-5"></div>
            <div className="connection-line connection-6"></div>
            <div className="connection-line connection-7"></div>
            <div className="connection-line connection-8"></div>
          </div>
        </motion.div>

        {/* Coming Soon Cloud/Tooltip */}
        <motion.div
          className="coming-soon-cloud absolute"
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ 
            opacity: isHovered ? 1 : 0,
            scale: isHovered ? 1 : 0.8,
            y: isHovered ? -120 : -100
          }}
          transition={{ 
            duration: 0.4,
            ease: "easeOut"
          }}
        >
          <div className="cloud-shape">
            <motion.div 
              className="cloud-text"
              animate={{ 
                textShadow: isHovered ? [
                  "0 0 10px rgba(255,255,255,0.8)",
                  "0 0 20px rgba(255,255,255,1)",
                  "0 0 10px rgba(255,255,255,0.8)"
                ] : "0 0 5px rgba(255,255,255,0.5)"
              }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              Coming Soon
            </motion.div>
            {/* Cloud bubbles */}
            <div className="cloud-bubble cloud-bubble-1"></div>
            <div className="cloud-bubble cloud-bubble-2"></div>
            <div className="cloud-bubble cloud-bubble-3"></div>
            <div className="cloud-bubble cloud-bubble-4"></div>
            <div className="cloud-bubble cloud-bubble-5"></div>
          </div>
          {/* Arrow pointing to hypercube */}
          <div className="cloud-arrow"></div>
        </motion.div>

        {/* Additional 4D dimensional effects */}
        <motion.div
          className="dimension-particles absolute inset-0 pointer-events-none"
          animate={{ 
            opacity: isHovered ? 0.6 : 0.2
          }}
          transition={{ duration: 0.3 }}
        >
          {Array.from({ length: 12 }, (_, i) => (
            <motion.div
              key={i}
              className="dimension-particle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                x: [0, Math.random() * 4 - 2],
                y: [0, Math.random() * 4 - 2],
                scale: [0.8, 1, 0.8],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2
              }}
            />
          ))}
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Hypercube4D;