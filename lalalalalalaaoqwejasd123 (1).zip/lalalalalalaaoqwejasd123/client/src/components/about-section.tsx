import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const AboutSection = () => {
  const [ref, inView] = useInView({
    threshold: 0.3,
    triggerOnce: true,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  const skills = [
    { icon: "fab fa-html5", name: "HTML5" },
    { icon: "fab fa-css3-alt", name: "CSS3" },
    { icon: "fab fa-js", name: "JavaScript" },
    { icon: "fab fa-react", name: "React" },
  ];

  return (
    <section id="about" className="min-h-screen flex items-center justify-center py-20" ref={ref}>
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="text-center mb-16"
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
          >
            <motion.h2 
              className="text-5xl md:text-6xl font-bold mb-8 text-glow-intense wiggle" 
              variants={itemVariants}
              animate={{
                textShadow: [
                  "0 0 10px rgba(255,255,255,0.8), 0 0 20px rgba(255,255,255,0.4), 0 0 30px rgba(255,255,255,0.2)",
                  "0 0 20px rgba(255,255,255,1), 0 0 40px rgba(255,255,255,0.6), 0 0 60px rgba(255,255,255,0.3)"
                ],
                scale: [1, 1.02]
              }}
              transition={{ duration: 4, repeat: Infinity }}
              data-testid="about-title"
            >
              About Me
            </motion.h2>
            <motion.div 
              className="w-24 h-1 bg-white mx-auto rounded-full" 
              variants={itemVariants}
            />
          </motion.div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              variants={itemVariants}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              transition={{ delay: 0.2 }}
            >
              <motion.div 
                className="relative"
                whileHover={{
                  scale: 1.05,
                  rotate: [0, -1, 1, 0]
                }}
                animate={{
                  y: [0, 0],
                  boxShadow: [
                    "0 0 20px rgba(255,255,255,0.1)",
                    "0 0 30px rgba(255,255,255,0.2)"
                  ]
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <motion.img 
                  src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                  alt="Developer workspace" 
                  className="rounded-lg glow w-full h-auto grayscale hover:grayscale-0 transition-all duration-500"
                  data-testid="about-image"
                  whileHover={{
                    filter: [
                      "grayscale(100%) brightness(1)",
                      "grayscale(0%) brightness(1.1) contrast(1.1)"
                    ]
                  }}
                  animate={{
                    filter: [
                      "grayscale(100%) brightness(1)",
                      "grayscale(90%) brightness(1.05)"
                    ]
                  }}
                  transition={{ duration: 6, repeat: Infinity }}
                />
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent rounded-lg pointer-events-none"
                  animate={{
                    opacity: [0.8, 0.6]
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                ></motion.div>
              </motion.div>
            </motion.div>
            
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              className="space-y-6"
            >
              <motion.h3 
                className="text-3xl font-bold text-glow-rainbow" 
                variants={itemVariants}
                data-testid="about-role"
              >
                Frontend Developer
              </motion.h3>
              
              <motion.p 
                className="text-lg text-muted-foreground leading-relaxed" 
                variants={itemVariants}
                data-testid="about-description-1"
              >
                Passionate about creating seamless user experiences through clean, efficient code. 
                Currently immersed in the world of frontend development, learning modern frameworks 
                and best practices.
              </motion.p>
              
              <motion.p 
                className="text-lg text-muted-foreground leading-relaxed" 
                variants={itemVariants}
                data-testid="about-description-2"
              >
                My journey into web development began with curiosity and has evolved into a dedicated 
                pursuit of crafting beautiful, functional interfaces that users love to interact with.
              </motion.p>
              
              <motion.div 
                className="flex flex-wrap gap-4 mt-8" 
                variants={itemVariants}
              >
                {skills.map((skill, index) => (
                  <motion.div
                    key={skill.name}
                    className="skill-badge rounded-full px-4 py-2"
                    whileHover={{ 
                      scale: 1.15, 
                      rotate: [0, -5, 5, 0],
                      y: -5,
                      boxShadow: "0 10px 25px rgba(255,255,255,0.2)"
                    }}
                    animate={{
                      y: [0, 0, 0],
                      rotate: [0, 1, -1, 0]
                    }}
                    transition={{ 
                      type: "spring", 
                      stiffness: 300,
                      duration: 2 + index * 0.3,
                      repeat: Infinity,
                      delay: index * 0.2
                    }}
                    data-testid={`skill-badge-${skill.name.toLowerCase()}`}
                  >
                    <motion.i 
                      className={`${skill.icon} mr-2`}
                      animate={{
                        rotate: [0, 360],
                        scale: [1, 1.2, 1]
                      }}
                      transition={{
                        duration: 4 + index,
                        repeat: Infinity,
                        delay: index * 0.5
                      }}
                    ></motion.i>
                    <motion.span
                      animate={{
                        textShadow: [
                          "0 0 0px rgba(255,255,255,0.5)",
                          "0 0 5px rgba(255,255,255,0.8)",
                          "0 0 0px rgba(255,255,255,0.5)"
                        ]
                      }}
                      transition={{ duration: 3, repeat: Infinity, delay: index * 0.3 }}
                    >
                      {skill.name}
                    </motion.span>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
