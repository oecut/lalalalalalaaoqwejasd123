import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const Footer = () => {
  const [ref, inView] = useInView({
    threshold: 0.3,
    triggerOnce: true,
  });

  const socialLinks = [
    {
      icon: "fab fa-github",
      href: "#",
      testId: "link-github"
    },
    {
      icon: "fab fa-telegram",
      href: "#",
      testId: "link-telegram"
    },
    {
      icon: "fab fa-linkedin",
      href: "#",
      testId: "link-linkedin"
    }
  ];

  return (
    <footer className="py-12 border-t border-border" ref={ref}>
      <div className="container mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <p className="text-muted-foreground mb-4" data-testid="footer-copyright">
            © 2025 @oecut_major. Crafted with passion and countless cups of coffee.
          </p>
          <div className="flex justify-center space-x-6">
            {socialLinks.map((link, index) => (
              <motion.a 
                key={index}
                href={link.href} 
                className="text-muted-foreground hover:text-white transition-colors duration-300"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300 }}
                data-testid={link.testId}
              >
                <i className={`${link.icon} text-xl`}></i>
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
