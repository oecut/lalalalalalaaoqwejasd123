import { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";

const OctahedronTimer = () => {
  const [isHovered, setIsHovered] = useState(false);
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Таймер обратного отсчета до 01.01.2026
  useEffect(() => {
    const targetDate = new Date('2026-01-01T00:00:00').getTime();
    let animationFrame: number;
    let lastUpdate = 0;

    const updateTimer = (timestamp: number) => {
      if (timestamp - lastUpdate >= 1000) {
        const now = new Date().getTime();
        const difference = targetDate - now;

        if (difference > 0) {
          const days = Math.floor(difference / (1000 * 60 * 60 * 24));
          const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((difference % (1000 * 60)) / 1000);

          setTimeLeft({ days, hours, minutes, seconds });
        }
        lastUpdate = timestamp;
      }
      animationFrame = requestAnimationFrame(updateTimer);
    };

    animationFrame = requestAnimationFrame(updateTimer);

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, []);

  return (
    <div className="relative flex justify-center items-center">
      {/* Octahedron Container */}
      <motion.div
        className="relative perspective-1000 cursor-pointer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        whileHover={{ scale: 1.1 }}
        transition={{ duration: 0.4 }}
        style={{ willChange: 'transform' }}
      >
        {/* Octahedron 3D Shape */}
        <motion.div
          className="octahedron-container transform-style-preserve-3d relative"
          animate={{ 
            rotateX: [0, 360],
            rotateY: [360, 0],
            rotateZ: [0, 180]
          }}
          transition={{ 
            duration: 35,
            repeat: Infinity,
            ease: "linear"
          }}
          style={{ willChange: 'transform' }}
        >
          {/* Top Pyramid */}
          <div className="octahedron-pyramid octahedron-top">
            <div className="octahedron-face octahedron-face-1">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
            <div className="octahedron-face octahedron-face-2">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
            <div className="octahedron-face octahedron-face-3">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
            <div className="octahedron-face octahedron-face-4">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
          </div>

          {/* Bottom Pyramid */}
          <motion.div 
            className="octahedron-pyramid octahedron-bottom"
            animate={{ 
              rotateY: [0, -360]
            }}
            transition={{ 
              duration: 40,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            <div className="octahedron-face octahedron-face-5">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
            <div className="octahedron-face octahedron-face-6">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
            <div className="octahedron-face octahedron-face-7">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
            <div className="octahedron-face octahedron-face-8">
              <div className="octahedron-inner-pattern">
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
                <div className="pattern-dot"></div>
              </div>
            </div>
          </motion.div>

          {/* Energy Lines */}
          <div className="octahedron-energy-lines">
            <div className="energy-line energy-line-1"></div>
            <div className="energy-line energy-line-2"></div>
            <div className="energy-line energy-line-3"></div>
            <div className="energy-line energy-line-4"></div>
          </div>
        </motion.div>

        {/* Timer Tooltip */}
        <motion.div
          className="timer-cloud absolute"
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ 
            opacity: isHovered ? 1 : 0,
            scale: isHovered ? 1 : 0.8,
            y: isHovered ? -130 : -110
          }}
          transition={{ 
            duration: 0.4,
            ease: "easeOut"
          }}
        >
          <div className="timer-shape">
            <motion.div 
              className="timer-content"
              animate={{ 
                boxShadow: isHovered ? [
                  "0 0 20px rgba(100,200,255,0.6)",
                  "0 0 40px rgba(100,200,255,1)",
                  "0 0 20px rgba(100,200,255,0.6)"
                ] : "0 0 10px rgba(100,200,255,0.3)"
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="timer-title">Проект запуск</div>
              <div className="timer-display">
                <div className="timer-unit">
                  <span className="timer-value">{String(timeLeft.days).padStart(2, '0')}</span>
                  <span className="timer-label">дни</span>
                </div>
                <div className="timer-separator">:</div>
                <div className="timer-unit">
                  <span className="timer-value">{String(timeLeft.hours).padStart(2, '0')}</span>
                  <span className="timer-label">часы</span>
                </div>
                <div className="timer-separator">:</div>
                <div className="timer-unit">
                  <span className="timer-value">{String(timeLeft.minutes).padStart(2, '0')}</span>
                  <span className="timer-label">мин</span>
                </div>
                <div className="timer-separator">:</div>
                <div className="timer-unit">
                  <span className="timer-value">{String(timeLeft.seconds).padStart(2, '0')}</span>
                  <span className="timer-label">сек</span>
                </div>
              </div>
              <div className="timer-subtitle">до 01.01.2026</div>
            </motion.div>
            {/* Timer bubbles */}
            <div className="timer-bubble timer-bubble-1"></div>
            <div className="timer-bubble timer-bubble-2"></div>
            <div className="timer-bubble timer-bubble-3"></div>
          </div>
          {/* Arrow pointing to octahedron */}
          <div className="timer-arrow"></div>
        </motion.div>

        {/* Particle Effects */}
        <motion.div
          className="octahedron-particles absolute inset-0 pointer-events-none"
          animate={{ 
            opacity: isHovered ? 0.8 : 0.3
          }}
          transition={{ duration: 0.3 }}
        >
          {useMemo(() => 
            Array.from({ length: 8 }, (_, i) => {
              const particleConfig = {
                left: Math.random() * 100,
                top: Math.random() * 100,
                xMove: Math.random() * 6 - 3,
                yMove: Math.random() * 6 - 3,
                duration: 3 + Math.random() * 2,
                delay: Math.random() * 2
              };
              
              return (
                <motion.div
                  key={i}
                  className="octahedron-particle"
                  style={{
                    left: `${particleConfig.left}%`,
                    top: `${particleConfig.top}%`,
                  }}
                  animate={{
                    x: [0, particleConfig.xMove],
                    y: [0, particleConfig.yMove],
                    scale: [0.6, 1.2, 0.6],
                    opacity: [0.2, 0.8, 0.2],
                    rotate: [0, 360]
                  }}
                  transition={{
                    duration: particleConfig.duration,
                    repeat: Infinity,
                    delay: particleConfig.delay
                  }}
                />
              );
            }), []
          )}
        </motion.div>
      </motion.div>
    </div>
  );
};

export default OctahedronTimer;