import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const SkillsSection = () => {
  const [ref, inView] = useInView({
    threshold: 0.3,
    triggerOnce: true,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  };

  const skills = [
    {
      icon: "fab fa-html5",
      name: "HTML5",
      description: "Semantic markup",
      delay: 0
    },
    {
      icon: "fab fa-css3-alt",
      name: "CSS3",
      description: "Modern styling",
      delay: 0.1
    },
    {
      icon: "fab fa-js",
      name: "JavaScript",
      description: "ES6+ features",
      delay: 0.2
    },
    {
      icon: "fab fa-react",
      name: "React",
      description: "Component-based",
      delay: 0.3
    },
    {
      icon: "fab fa-git-alt",
      name: "Git",
      description: "Version control",
      delay: 0.4
    },
    {
      icon: "fab fa-figma",
      name: "Figma",
      description: "UI/UX design",
      delay: 0.5
    },
    {
      icon: "fas fa-mobile-alt",
      name: "Responsive",
      description: "Mobile-first",
      delay: 0.6
    },
    {
      icon: "fas fa-rocket",
      name: "Performance",
      description: "Optimization",
      delay: 0.7
    }
  ];

  return (
    <section id="skills" className="min-h-screen flex items-center justify-center py-20" ref={ref}>
      <div className="container mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          <motion.h2 
            className="text-5xl md:text-6xl font-bold mb-8 text-glow-rainbow" 
            variants={itemVariants}
            data-testid="skills-title"
          >
            Skills & Technologies
          </motion.h2>
          <motion.div 
            className="w-24 h-1 bg-white mx-auto rounded-full" 
            variants={itemVariants}
          />
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-6"
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
          >
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                className="skill-badge rounded-xl p-6 text-center"
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.05, 
                  y: -5,
                  transition: { type: "spring", stiffness: 300 }
                }}
                data-testid={`skill-${skill.name.toLowerCase()}`}
              >
                <i className={`${skill.icon} text-4xl mb-4`}></i>
                
                <h3 
                  className="font-semibold" 
                  data-testid={`skill-name-${skill.name.toLowerCase()}`}
                >
                  {skill.name}
                </h3>
                <p 
                  className="text-sm text-muted-foreground mt-2" 
                  data-testid={`skill-description-${skill.name.toLowerCase()}`}
                >
                  {skill.description}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
