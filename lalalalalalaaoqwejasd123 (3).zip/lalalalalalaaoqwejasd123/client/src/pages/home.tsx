import { useEffect } from "react";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import ProjectsSection from "@/components/projects-section";
import SkillsSection from "@/components/skills-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";

const Home = () => {
  useEffect(() => {
    // Add smooth scroll behavior to the body
    document.body.style.scrollBehavior = 'smooth';
    
    // Cleanup
    return () => {
      document.body.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Дополнительные анимированные объекты для фона */}
      <div className="extra-background-objects">
        <div className="floating-diamond"></div>
        <div className="floating-diamond"></div>
        <div className="floating-diamond"></div>
        <div className="floating-hexagon"></div>
        <div className="floating-hexagon"></div>
        <div className="floating-star"></div>
        <div className="floating-star"></div>
        <div className="floating-star"></div>
      </div>
      
      <Navigation />
      <HeroSection />
      <AboutSection />
      <ProjectsSection />
      <SkillsSection />
      <ContactSection />
      <Footer />
    </div>
  );
};

export default Home;
